@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo Nexra External - local C++ x64 build
echo No dependency downloads. Dear ImGui and Inter are bundled.
if not exist "build" mkdir "build"
set "SOURCES=src\main.cpp src\provider.cpp src\renderer.cpp src\avatar.cpp vendor\imgui\imgui.cpp vendor\imgui\imgui_draw.cpp vendor\imgui\imgui_tables.cpp vendor\imgui\imgui_widgets.cpp vendor\imgui\backends\imgui_impl_win32.cpp vendor\imgui\backends\imgui_impl_dx11.cpp"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if exist "%VSWHERE%" (
  for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%i"
)
if defined VSROOT call "%VSROOT%\VC\Auxiliary\Build\vcvars64.bat" >nul
where cl >nul 2>nul
if not errorlevel 1 goto msvc
where g++ >nul 2>nul
if not errorlevel 1 goto mingw
echo.
echo No Windows C++ compiler found.
echo Install Visual Studio 2022 Build Tools with Desktop development with C++
echo and a Windows SDK, then run this file again. Or use 64-bit MinGW-w64.
echo The supplied RobloxExternal.exe does not require a compiler.
goto failed

:msvc
where rc >nul 2>nul
if errorlevel 1 (
  echo Windows resource compiler missing. Install the Windows SDK.
  goto failed
)
rc /nologo /fo build\app.res app.rc
if errorlevel 1 goto failed
cl /nologo /std:c++17 /EHsc /O2 /MT /utf-8 /W3 /DNDEBUG /DUNICODE /D_UNICODE /DNOMINMAX /DWIN32_LEAN_AND_MEAN /DIMGUI_IMPL_WIN32_DISABLE_GAMEPAD /I vendor\imgui /I src /Fo"build\\" /Fe"RobloxExternal.exe" %SOURCES% build\app.res /link /SUBSYSTEM:WINDOWS /MACHINE:X64 /DYNAMICBASE /NXCOMPAT /MANIFEST:NO d3d11.lib dxgi.lib d3dcompiler.lib dwmapi.lib user32.lib gdi32.lib shell32.lib imm32.lib winhttp.lib ole32.lib windowscodecs.lib uuid.lib
if errorlevel 1 goto failed
goto done

:mingw
g++ -dumpmachine | findstr /i "x86_64.*mingw" >nul
if errorlevel 1 (
  echo This must be a Windows x64 MinGW-w64 compiler, not WSL or 32-bit GCC.
  goto failed
)
where windres >nul 2>nul
if errorlevel 1 (
  echo windres not found. Install the MinGW-w64 binutils package.
  goto failed
)
windres app.rc -O coff -o build\app-resource.o
if errorlevel 1 goto failed
g++ -std=c++17 -O2 -DNDEBUG -DUNICODE -D_UNICODE -DNOMINMAX -DWIN32_LEAN_AND_MEAN -DIMGUI_IMPL_WIN32_DISABLE_GAMEPAD -Ivendor\imgui -Isrc %SOURCES% build\app-resource.o -o RobloxExternal.exe -mwindows -municode -static -static-libgcc -static-libstdc++ -ld3d11 -ldxgi -ld3dcompiler -ldwmapi -luser32 -lgdi32 -lshell32 -limm32 -lwinhttp -lole32 -lwindowscodecs -luuid
if errorlevel 1 goto failed

:done
echo.
echo Build succeeded: %CD%\RobloxExternal.exe
echo run-demo.bat previews the menu without Roblox. run-live.bat uses the live reader.
if /i not "%~1"=="--no-pause" pause
exit /b 0

:failed
echo.
echo Build failed. Review the compiler message above.
if /i not "%~1"=="--no-pause" pause
exit /b 1
