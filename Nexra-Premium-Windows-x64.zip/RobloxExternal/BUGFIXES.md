# Bug-fix build 1.0.1 — 2026-10-01

This is a tested repair pass, not a claim of provably bug-free software or verified live Roblox compatibility.

## Reproduced defects fixed

The eight standalone pre-fix reproductions below each reported a defect before the changes and no defect after them. They are also covered by the expanded included regression tests.

| Defect | Repair |
|---|---|
| NaN FOV bypassed aim filtering | Reject non-finite and nonpositive FOV values before selection. |
| NaN aim range bypassed range filtering | Reject invalid ranges before selection. |
| NaN delta time produced invalid mouse movement | Reject invalid time and coordinate inputs before smoothing. |
| Zero delta time still produced movement | Zero/negative delta time returns zero movement. |
| Settings clamps retained NaN values | Restore safe defaults before finite bounds are applied, including colors. |
| UTF-8 BOM hid the first INI section | Strip the BOM and normalize section/key casing. |
| A decimal offset such as `018` was misinterpreted | Parse decimal explicitly; hexadecimal requires `0x`. |
| Negative offsets were accepted as unsigned values | Reject signs, overflow, malformed values, and invalid schema ranges. |

## Additional correctness and lifecycle repairs

- **Reload/source races:** source changes and reloads synchronously invalidate the snapshot and increase its revision. Late worker frames cannot overwrite the new source or generation. In-flight frames from the wrong mode are rejected.
- **Attachment cleanup:** failed partial attachments release process handles. Process selection favors the foreground game or the largest available game window.
- **Schema checks:** required values must be present and valid. Zero object-member offsets are permitted where meaningful; global pointer RVAs must be nonzero. An exact-shaped version identifier is required, but it is not proof of a correct live layout.
- **Scene changes:** watch for DataModel changes every sample, discard old entity caches, and refresh changed team labels.
- **Freshness:** age input data from the start of frame sampling. Reject expired/future timestamps and invalid matrices.
- **Layered window creation:** removed `CS_CLASSDC`, which is incompatible with `WS_EX_LAYERED`; use ordinary redraw class flags.
- **DX11 resources:** release partial device creation, unbind back buffers before resize, check backend initialization and presentation, clean up on exceptions, and attempt device recreation on removal/reset. Device loss and all native GPU variants have not been exercised.
- **Mouse coordinates:** absolute output converts through the game HWND rather than the overlay HWND. Recheck target-window ownership, focus and RMB immediately before output; reject an outside-client absolute cursor.
- **Integer mouse movement:** finite, bounded residual accumulation prevents diagonal rounding from exceeding the configured integer step cap. Clearing the menu/target/focus conditions resets accumulated movement.
- **Truthful status:** distinguish a command actually sent from a sub-pixel/no-movement tracking frame and from blocked or failed input.
- **Duplicate instances:** a per-session guard prevents parallel controllers; a second launch requests the existing menu.
- **Rendering:** sanitize settings before illustrated previews, render numeric health on bottom bars too, validate health fractions, correct directly-behind off-screen direction, make sidebar navigation scrollable, scale the preview, and provide a small-display fallback rather than invalid layout dimensions.
- **Config operations:** textual booleans, quoted values and inline comments are supported. Invalid/empty/unrelated loads preserve current settings. Saves use a temporary file and replacement so a failed replacement preserves the old destination.

## Test scope

- 101 core/settings/state assertions pass on Linux and on the Windows build under Wine.
- 10,000 randomized movement cases per core run remain within the integer step cap.
- AddressSanitizer and UndefinedBehaviorSanitizer core run passes without reported findings.
- 59 Windows provider checks under Wine cover demo output, source/reload revision changes, missing-profile failure, repeated transitions and worker destruction.
- The rebuilt EXE starts and renders its bundled font, navigates pages, honors Insert, selects simulated targets without mouse output, and prevents a duplicate instance.

See `VALIDATION.md` for the final binary fingerprint and limits. The live profile remains explicitly unverified. Native Windows/MSVC, current Roblox internals, real camera response, unusual displays and all driver/error conditions cannot be certified by these tests.
