#pragma once
#include "core.hpp"
#include <sstream>
#include <locale>
namespace ext {
struct RadarOptions {
    int shape=0,orientation=0,corner=1;
    float size=210,opacity=.90f,dotSize=4;
    bool edgeMarkers=true,labels=false,altitude=true,rings=true;
};
struct RadarPoint {Vec2 offset{};bool edge=false;float altitude=0;};
inline std::optional<RadarPoint> radarPoint(Vec3 position,Vec3 local,float range,float radius,
                                          float yaw,bool cameraUp,bool square,bool edges){
    if(!finite(position)||!finite(local)||!std::isfinite(range)||range<=0||!std::isfinite(radius)||radius<=0||!std::isfinite(yaw)) return {};
    double x=double(position.x)-local.x,z=double(position.z)-local.z;
    if(cameraUp){double c=std::cos(yaw),s=std::sin(yaw),old=x;x=x*c+z*s;z=-old*s+z*c;}
    double metric=square?std::max(std::abs(x),std::abs(z)):std::hypot(x,z);bool edge=metric>range;
    if(edge&&!edges) return {};
    double scale=radius/std::max(double(range),metric);
    return RadarPoint{{float(x*scale),float(z*scale)},edge,position.y-local.y};
}
struct RecoilSegment {float durationMs=0,x=0,y=0;};
inline std::optional<std::vector<RecoilSegment>> parsePattern(const std::string& input){
    if(input.empty()||input.size()>1024) return {};
    std::vector<RecoilSegment> result;std::istringstream rows(input);rows.imbue(std::locale::classic());std::string row;double duration=0;
    while(std::getline(rows,row,';')){
        if(row.empty()||result.size()>=16) return {};
        std::replace(row.begin(),row.end(),',',' ');std::istringstream values(row);values.imbue(std::locale::classic());
        RecoilSegment segment;
        if(!(values>>segment.durationMs>>segment.x>>segment.y)) return {};
        values>>std::ws;if(!values.eof()||!std::isfinite(segment.durationMs)||!std::isfinite(segment.x)||!std::isfinite(segment.y)||
            segment.durationMs<10||segment.durationMs>5000||std::abs(segment.x)>600||std::abs(segment.y)>600) return {};
        duration+=segment.durationMs;if(duration>30000) return {};
        result.push_back(segment);
    }
    if(input.back()==';'||result.empty()) return {};
    return result;
}
struct RecoilOptions {
    bool enabled=false;
    int mode=0;
    float horizontal=0,vertical=75,delayMs=50,maxStep=18;
    std::string pattern="200,0,75;300,0,100;400,0,60";
};
inline Vec2 recoilStep(const RecoilOptions& options,const std::vector<RecoilSegment>& pattern,double elapsedMs,float dt){
    if(!std::isfinite(elapsedMs)||elapsedMs<0||!std::isfinite(dt)||dt<=0||!std::isfinite(options.delayMs)||options.delayMs<0||
       !std::isfinite(options.maxStep)||options.maxStep<1||options.maxStep>100||options.mode<0||options.mode>1) return {};
    double from=std::max(0.0,elapsedMs-options.delayMs),to=std::max(0.0,elapsedMs+std::min(double(dt),.05)*1000-options.delayMs);
    if(to<=from) return {};
    double x=0,y=0;
    if(options.mode==0){
        if(!std::isfinite(options.horizontal)||!std::isfinite(options.vertical)||std::abs(options.horizontal)>600||std::abs(options.vertical)>600) return {};
        x=options.horizontal*(to-from)/1000;y=options.vertical*(to-from)/1000;
    }else{
        double end=0;
        for(const auto& segment:pattern){
            if(!std::isfinite(segment.durationMs)||segment.durationMs<10||segment.durationMs>5000||
               !std::isfinite(segment.x)||!std::isfinite(segment.y)||std::abs(segment.x)>600||std::abs(segment.y)>600) return {};
            double overlap=std::max(0.0,std::min(to,end+segment.durationMs)-std::max(from,end));
            x+=segment.x*overlap/1000;y+=segment.y*overlap/1000;end+=segment.durationMs;
        }
    }
    double norm=std::hypot(x,y);if(norm>options.maxStep){x*=options.maxStep/norm;y*=options.maxStep/norm;}
    return {float(x),float(y)};
}
inline bool allowRecoilOutput(const Snapshot& scene,const RecoilOptions& options,bool live,bool menu,bool focused,bool left,bool right,Clock::time_point now){
    return options.enabled&&live&&!scene.demo&&scene.pid&&scene.targetWindow&&!menu&&focused&&left&&right&&fresh(scene,now);
}
// Avatar URLs are public HTTPS metadata; never accept arbitrary hosts, local files, or user scripts.
inline bool avatarHost(const std::wstring& host){
    const std::wstring suffix=L".rbxcdn.com";
    return host==L"thumbnails.roblox.com"||host==L"rbxcdn.com"||
        (host.size()>suffix.size()&&host.compare(host.size()-suffix.size(),suffix.size(),suffix)==0);
}
}
