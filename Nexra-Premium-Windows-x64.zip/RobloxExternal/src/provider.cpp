#include "provider.hpp"
#include <tlhelp32.h>
#include <cwctype>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <ctime>

namespace ext {
namespace {
HWND gameWindow(DWORD pid);
bool pointer(uint64_t p) { return p>=0x10000ULL&&p<0x00007FFFFFFF0000ULL; }
struct Memory {
    HANDLE handle=nullptr;
    DWORD pid=0;
    uint64_t base=0;
    std::wstring path;
    std::string version,error;
    ~Memory(){ close(); }
    void close(){ if(handle) CloseHandle(handle); handle=nullptr;pid=0;base=0;path.clear();version.clear(); }
    bool alive() const { return handle&&WaitForSingleObject(handle,0)==WAIT_TIMEOUT; }
    bool bytes(uint64_t address,void* data,size_t count) const {
        if(!handle||!pointer(address)||!count||count>1024*1024||address+count<address||!pointer(address+count-1)) return false;
        SIZE_T done=0;
        return ReadProcessMemory(handle,reinterpret_cast<LPCVOID>(address),data,count,&done)&&done==count;
    }
    template<class T> bool read(uint64_t a,T& out) const { T v{};if(!bytes(a,&v,sizeof v)) return false;out=v;return true; }
    template<class T> T get(uint64_t a) const { T value{};read(a,value);return value; }
    bool attach(){
        close(); error.clear();
        HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
        if(snap==INVALID_HANDLE_VALUE){error="Process enumeration failed";return false;}
        PROCESSENTRY32W pe{};pe.dwSize=sizeof pe;
        std::vector<DWORD> candidates;
        if(Process32FirstW(snap,&pe)) do {
            if(_wcsicmp(pe.szExeFile,L"RobloxPlayerBeta.exe")==0) candidates.push_back(pe.th32ProcessID);
        }while(Process32NextW(snap,&pe));
        CloseHandle(snap);
        DWORD foregroundPid=0;GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
        uint64_t bestArea=0;
        for(auto candidate:candidates){
            HWND window=gameWindow(candidate);RECT rect{};
            if(!window||IsIconic(window)||!GetClientRect(window,&rect)) continue;
            if(candidate==foregroundPid){pid=candidate;break;}
            uint64_t area=uint64_t(std::max(LONG(0),rect.right))*uint64_t(std::max(LONG(0),rect.bottom));
            if(area>bestArea){bestArea=area;pid=candidate;}
        }
        if(!pid&&!candidates.empty()) pid=candidates.front();
        if(!pid){error="Waiting for RobloxPlayerBeta.exe";return false;}
        handle=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ|SYNCHRONIZE,FALSE,pid);
        if(!handle){error="Windows denied read access (error "+std::to_string(GetLastError())+"). No bypass is included.";return false;}
        auto fail=[&](const std::string& message){error=message;CloseHandle(handle);handle=nullptr;base=0;return false;};
        wchar_t buffer[32768]{};DWORD size=32768;
        if(!QueryFullProcessImageNameW(handle,0,buffer,&size)) return fail("Cannot identify the client executable");
        path.assign(buffer,size);
        auto parent=std::filesystem::path(path).parent_path().filename().wstring();
        for(auto& c:parent) if(c>=L'A'&&c<=L'Z') c=wchar_t(c-L'A'+L'a');
        if(parent.rfind(L"version-",0)==0) version=std::string(parent.begin(),parent.end());
        HANDLE modules=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE|TH32CS_SNAPMODULE32,pid);
        if(modules==INVALID_HANDLE_VALUE) return fail("Module enumeration failed (error "+std::to_string(GetLastError())+")");
        MODULEENTRY32W me{};me.dwSize=sizeof me;
        if(Module32FirstW(modules,&me)) do {
            if(_wcsicmp(me.szModule,L"RobloxPlayerBeta.exe")==0){base=reinterpret_cast<uint64_t>(me.modBaseAddr);break;}
        }while(Module32NextW(modules,&me));
        CloseHandle(modules);
        if(!base) return fail("Roblox module base was not available");
        return true;
    }
    std::string string(uint64_t object) const {
        uint64_t length=0,capacity=0;
        if(!read(object+0x10,length)||!read(object+0x18,capacity)||length==0||length>128||capacity<length||capacity>65536) return {};
        uint64_t address=capacity<16?object:get<uint64_t>(object);
        std::string result(size_t(length),'\0');
        if(!bytes(address,result.data(),result.size())) return {};
        for(auto& c:result) if(static_cast<unsigned char>(c)<32) c=' ';
        return result;
    }
};
struct WindowSearch{DWORD pid;HWND best=nullptr;uint64_t area=0;};
BOOL CALLBACK findWindow(HWND hwnd,LPARAM arg){
    auto& data=*reinterpret_cast<WindowSearch*>(arg);DWORD pid=0;GetWindowThreadProcessId(hwnd,&pid);
    if(pid!=data.pid||!IsWindowVisible(hwnd)||GetWindow(hwnd,GW_OWNER)) return TRUE;
    RECT r{};if(!GetClientRect(hwnd,&r)||r.right<=r.left||r.bottom<=r.top) return TRUE;
    uint64_t area=uint64_t(r.right-r.left)*uint64_t(r.bottom-r.top);
    if(area>data.area){data.area=area;data.best=hwnd;}return TRUE;
}
HWND gameWindow(DWORD pid){WindowSearch data{pid};if(pid) EnumWindows(findWindow,reinterpret_cast<LPARAM>(&data));return data.best;}
struct Offsets {
    Ini ini;std::string version,error;
    uint64_t operator()(const char* key) const{return ini.offset(key);}
    bool load(const std::filesystem::path& file){
        error.clear();if(!ini.load(file)){error="Missing profiles/roblox.ini";return false;}
        version=ini.get("Profile.ClientVersion");
        for(auto& c:version) if(c>='A'&&c<='Z') c=char(c-'A'+'a');
        if(version.size()!=24||version.rfind("version-",0)!=0||version.find_first_not_of("0123456789abcdef",8)!=std::string::npos){
            error="Profile.ClientVersion must be version- followed by 16 hexadecimal digits";return false;
        }
        for(const char* key:{"VisualEngine.Pointer","VisualEngine.ViewMatrix","FakeDataModel.Pointer","FakeDataModel.RealDataModel",
            "Instance.ChildrenStart","Instance.ChildrenEnd","Instance.NameContainer","Instance.Name","Instance.ClassDescriptor",
            "Instance.ClassName","Player.LocalPlayer","Player.ModelInstance","Player.Team","BasePart.Primitive",
            "Primitive.Position","Primitive.Rotation","Primitive.Size","Humanoid.Health","Humanoid.MaxHealth",
            "Workspace.CurrentCamera","Camera.Position"}) {
            auto value=ini.parsedOffset(key);
            if(!value){error=std::string("Profile missing or invalid offset: ")+key;return false;}
            bool global=std::string(key)=="VisualEngine.Pointer"||std::string(key)=="FakeDataModel.Pointer";
            if((global&&(*value==0||*value>0x40000000ULL))||(!global&&*value>0x10000ULL)){
                error=std::string("Offset is out of range: ")+key;return false;
            }
        }
        for(const char* key:{"VisualEngine.FakeDataModel","Primitive.AssemblyLinearVelocity","Player.UserId","Camera.Rotation"}) if(ini.contains(key)){
            auto value=ini.parsedOffset(key);if(!value||*value>0x10000ULL){error=std::string("Invalid optional offset: ")+key;return false;}
        }
        return true;
    }
};
struct InstanceReader {
    const Memory& m;const Offsets& o;
    std::string name(uint64_t instance) const {
        if(!pointer(instance)) return {};
        auto c=m.get<uint64_t>(instance+o("Instance.NameContainer"));
        return pointer(c)?m.string(c+o("Instance.Name")):std::string{};
    }
    std::string className(uint64_t instance) const {
        if(!pointer(instance)) return {};
        auto c=m.get<uint64_t>(instance+o("Instance.ClassDescriptor"));
        auto s=pointer(c)?m.get<uint64_t>(c+o("Instance.ClassName")):0;
        return pointer(s)?m.string(s):std::string{};
    }
    std::vector<uint64_t> children(uint64_t instance) const {
        std::vector<uint64_t> out;
        if(!pointer(instance)) return out;
        auto container=m.get<uint64_t>(instance+o("Instance.ChildrenStart"));
        if(!pointer(container)) return out;
        auto begin=m.get<uint64_t>(container),end=m.get<uint64_t>(container+o("Instance.ChildrenEnd"));
        if(!pointer(begin)||end<begin||end-begin>4096*16||(end-begin)%16) return out;
        struct Node{uint64_t object,reference;};std::vector<Node> nodes(size_t((end-begin)/16));
        if(nodes.empty()||!m.bytes(begin,nodes.data(),nodes.size()*sizeof(Node))) return out;
        for(auto n:nodes) if(pointer(n.object)) out.push_back(n.object);
        return out;
    }
    uint64_t byClass(uint64_t instance,const char* wanted) const {
        for(auto child:children(instance)) if(className(child)==wanted) return child;
        return 0;
    }
    Part part(uint64_t object) const {
        Part p;if(!pointer(object)) return p;
        auto primitive=m.get<uint64_t>(object+o("BasePart.Primitive"));
        if(!pointer(primitive)||!m.read(primitive+o("Primitive.Position"),p.position)||
            !m.read(primitive+o("Primitive.Size"),p.size)||!m.read(primitive+o("Primitive.Rotation"),p.rotation)) return p;
        if(!finite(p.position)||!finite(p.size)||length(p.position)>1e8f||
            p.size.x<=0||p.size.y<=0||p.size.z<=0||p.size.x>500||p.size.y>500||p.size.z>500) return p;
        for(float v:p.rotation.m) if(!std::isfinite(v)||std::abs(v)>1.1f) return p;
        p.valid=true;return p;
    }
};
struct CachedEntity {
    Entity info;uint64_t player=0,character=0,humanoid=0;
    std::array<uint64_t,BoneCount> parts{};
    bool r6=false;
};
constexpr const char* RigNames[BoneCount]{"Head","UpperTorso","LowerTorso","LeftUpperArm","LeftLowerArm","LeftHand",
    "RightUpperArm","RightLowerArm","RightHand","LeftUpperLeg","LeftLowerLeg","LeftFoot","RightUpperLeg",
    "RightLowerLeg","RightFoot","HumanoidRootPart"};
void r6Joints(Entity& e){
    if(e.parts[Torso].valid){e.parts[Pelvis]=e.parts[Torso];e.parts[Pelvis].position=e.parts[Torso].position+
        e.parts[Torso].rotation.apply({0,-e.parts[Torso].size.y*0.4f,0});e.parts[Pelvis].size={0.2f,0.2f,0.2f};}
    for(auto ids:std::array<std::array<int,3>,4>{{{LUpperArm,LLowerArm,LHand},{RUpperArm,RLowerArm,RHand},
                                                   {LUpperLeg,LLowerLeg,LFoot},{RUpperLeg,RLowerLeg,RFoot}}}){
        Part full=e.parts[ids[0]];if(!full.valid) continue;
        e.parts[ids[1]]=full;e.parts[ids[2]]=full;
        e.parts[ids[0]].position=full.position+full.rotation.apply({0,full.size.y*0.4f,0});
        e.parts[ids[2]].position=full.position+full.rotation.apply({0,-full.size.y*0.5f,0});
        e.parts[ids[0]].size=e.parts[ids[1]].size=e.parts[ids[2]].size={0.15f,0.15f,0.15f};
    }
}
Snapshot demoSnapshot(float time){
    Snapshot s;s.valid=true;s.demo=true;s.status="DEMO: simulated entities; mouse output disabled";
    s.view.m[0]=1.f/16;s.view.m[5]=1.f/9;s.view.m[10]=1;s.view.m[15]=1;
    s.localName="Demo account";s.localUserId=0;s.localTeam=1;s.localPosition={0,-3,0};s.camera={0,0,-25};s.version="Simulated scene";
    const Vec3 offsets[BoneCount]{{0,3.05f,0},{0,1.8f,0},{0,0.75f,0},{-1.35f,2,0},{-1.55f,1.3f,0},{-1.6f,0.55f,0},
        {1.35f,2,0},{1.55f,1.3f,0},{1.6f,0.55f,0},{-0.48f,-0.05f,0},{-0.48f,-0.85f,0},{-0.48f,-1.6f,-0.1f},
        {0.48f,-0.05f,0},{0.48f,-0.85f,0},{0.48f,-1.6f,-0.1f},{0,0.85f,0}};
    for(int k=0;k<7;++k){
        Entity e;e.id=uint64_t(k+1);e.name="Demo player "+std::to_string(k+1);e.team=k==2?1:2;e.teamName=e.team==1?"Blue":"Red";
        float x=-12.f+k*4.f+std::sin(time*0.6f+k)*1.5f;
        Vec3 root{x,-2.4f+std::sin(time+k)*0.2f,float(k*4)};
        e.velocity={0.9f*std::cos(time*0.6f+k),0.2f*std::cos(time+k),0};
        e.health=std::clamp(55.f+43.f*std::sin(time*0.25f+k),1.f,100.f);
        float yaw=std::sin(time*0.3f+k)*0.45f;
        Mat3 rotation{{std::cos(yaw),0,std::sin(yaw),0,1,0,-std::sin(yaw),0,std::cos(yaw)}};
        for(int j=0;j<BoneCount;++j){
            auto& p=e.parts[j];p.valid=true;p.rotation=rotation;p.position=root+rotation.apply(offsets[j]);
            p.size=j==Head?Vec3{1.1f,1.1f,1.1f}:j==Torso?Vec3{1.85f,1.3f,0.85f}:j==Pelvis?Vec3{1.7f,0.7f,0.8f}:
                j==Root?Vec3{1.5f,1.3f,0.7f}:Vec3{0.65f,0.72f,0.65f};
        }
        s.entities.push_back(std::move(e));
    }
    s.sampled=Clock::now();return s;
}
}
Provider::Provider(std::filesystem::path folder):folder_(std::move(folder)),thread_(&Provider::run,this){}
Provider::~Provider(){stop_=true;if(thread_.joinable()) thread_.join();}
void Provider::run(){
    Memory m;Offsets o;bool profileOk=false,attached=false;
    std::vector<CachedEntity> cache;uint64_t visual=0,players=0,workspace=0,local=0,cachedModel=0;
    auto nextAttach=Clock::now(),nextCache=Clock::now(),start=Clock::now();
    std::string lastLog;
    auto log=[&](const std::string& message){
        if(lastLog==message) return;
        lastLog=message;std::ofstream f(folder_/"external.log",std::ios::app);
        auto now=std::time(nullptr);f<<std::put_time(std::localtime(&now),"%Y-%m-%d %H:%M:%S")<<" "<<message<<"\n";
    };
    while(!stop_){
        auto now=Clock::now();auto request=store_.consumeRequest();
        if(request.reload){
            m.close();attached=false;cache.clear();visual=players=workspace=local=cachedModel=0;
            profileOk=o.load(folder_/"profiles"/"roblox.ini");nextAttach=nextCache=now;
        }
        if(request.mode==Demo){store_.publish(demoSnapshot(std::chrono::duration<float>(now-start).count()),request.revision);
            sampleCostMs_=std::chrono::duration<double,std::milli>(Clock::now()-now).count();
            std::this_thread::sleep_until(now+std::chrono::milliseconds(1000/(foreground_.load()?hz_.load():10)));continue;}
        Snapshot s;s.status="Waiting for Roblox";
        if(!profileOk) s.status=o.error;
        else if(!attached||!m.alive()){
            attached=false;cache.clear();
            if(now>=nextAttach){
                attached=m.attach();nextAttach=now+std::chrono::seconds(2);nextCache=now;
                if(!attached) s.status=m.error;
            }else s.status=m.error.empty()?"Waiting for RobloxPlayerBeta.exe":m.error;
        }
        s.pid=m.pid;s.targetWindow=reinterpret_cast<uintptr_t>(gameWindow(m.pid));s.version=m.version;
        if(attached&&profileOk){
            if(m.version.empty()) s.status="Cannot identify a version-* build folder. This client is unsupported.";
            else if(m.version!=o.version) s.status="Build mismatch. Detected "+m.version+"; profile expects "+o.version+". Reads and aim are disabled.";
            else {
                InstanceReader r{m,o};
                visual=m.get<uint64_t>(m.base+o("VisualEngine.Pointer"));
                uint64_t fake=m.get<uint64_t>(m.base+o("FakeDataModel.Pointer"));
                if(!pointer(fake)&&pointer(visual)&&o.ini.contains("VisualEngine.FakeDataModel"))
                    fake=m.get<uint64_t>(visual+o("VisualEngine.FakeDataModel"));
                uint64_t dm=pointer(fake)?m.get<uint64_t>(fake+o("FakeDataModel.RealDataModel")):0;
                if(dm!=cachedModel){cachedModel=dm;cache.clear();players=workspace=local=0;nextCache=now;}
                if(now>=nextCache){
                    cache.clear();
                    players=pointer(dm)?r.byClass(dm,"Players"):0;
                    workspace=pointer(dm)?r.byClass(dm,"Workspace"):0;
                    local=pointer(players)?m.get<uint64_t>(players+o("Player.LocalPlayer")):0;
                    if(pointer(players)&&pointer(local)){
                        auto list=r.children(players);if(list.size()>256) list.resize(256);
                        for(auto player:list){
                            if(player==local||r.className(player)!="Player") continue;
                            CachedEntity c;c.player=player;c.info.id=player;c.info.name=r.name(player);if(c.info.name.empty()) c.info.name="Player";
                            c.character=m.get<uint64_t>(player+o("Player.ModelInstance"));if(!pointer(c.character)) continue;
                            c.info.team=m.get<uint64_t>(player+o("Player.Team"));
                            if(pointer(c.info.team)) c.info.teamName=r.name(c.info.team);
                            std::unordered_map<std::string,uint64_t> parts;
                            for(auto child:r.children(c.character)){
                                auto cls=r.className(child);if(cls=="Humanoid") c.humanoid=child;
                                if(cls=="Part"||cls=="MeshPart"||cls=="UnionOperation") parts[r.name(child)]=child;
                            }
                            if(!pointer(c.humanoid)) continue;
                            c.r6=parts.count("Torso")>0&&parts.count("UpperTorso")==0;
                            for(int k=0;k<BoneCount;++k){auto it=parts.find(RigNames[k]);if(it!=parts.end()) c.parts[k]=it->second;}
                            if(c.r6){
                                c.parts[Torso]=parts["Torso"];c.parts[LUpperArm]=parts["Left Arm"];c.parts[RUpperArm]=parts["Right Arm"];
                                c.parts[LUpperLeg]=parts["Left Leg"];c.parts[RUpperLeg]=parts["Right Leg"];
                            }
                            if(!pointer(c.parts[Root])) continue;
                            cache.push_back(std::move(c));
                        }
                    }
                    nextCache=now+std::chrono::milliseconds(cacheMs_.load());
                }
                auto camera=pointer(workspace)?m.get<uint64_t>(workspace+o("Workspace.CurrentCamera")):0;
                auto sampled=Clock::now();
                bool ready=pointer(visual)&&pointer(players)&&pointer(local)&&pointer(camera)&&
                    m.read(visual+o("VisualEngine.ViewMatrix"),s.view)&&m.read(camera+o("Camera.Position"),s.camera);
                if(ready){
                    ready=validViewMatrix(s.view)&&finite(s.camera);
                }
                if(ready){
                    s.localTeam=m.get<uint64_t>(local+o("Player.Team"));s.localPosition=s.camera;
                    s.localName=r.name(local);
                    if(o.ini.contains("Player.UserId")){auto user=m.get<uint64_t>(local+o("Player.UserId"));if(user>0&&user<1000000000000ULL) s.localUserId=user;}
                    if(o.ini.contains("Camera.Rotation")){Mat3 rotation;if(m.read(camera+o("Camera.Rotation"),rotation)&&std::isfinite(rotation.m[2])&&std::isfinite(rotation.m[8])) s.cameraYaw=std::atan2(-rotation.m[2],rotation.m[8]);}
                    auto localCharacter=m.get<uint64_t>(local+o("Player.ModelInstance"));
                    for(auto child:r.children(localCharacter)) if(r.name(child)=="HumanoidRootPart"){
                        auto p=r.part(child);if(p.valid) s.localPosition=p.position;break;
                    }
                    for(const auto& c:cache){
                        if(m.get<uint64_t>(c.player+o("Player.ModelInstance"))!=c.character) continue;
                        Entity e=c.info;
                        if(!m.read(c.humanoid+o("Humanoid.Health"),e.health)||!m.read(c.humanoid+o("Humanoid.MaxHealth"),e.maxHealth)||
                            !std::isfinite(e.health)||!std::isfinite(e.maxHealth)||e.maxHealth<=0||e.maxHealth>1e8f||e.health<0||e.health>1e8f) continue;
                        e.team=m.get<uint64_t>(c.player+o("Player.Team"));
                        if(e.team!=c.info.team) e.teamName=pointer(e.team)?r.name(e.team):std::string{};
                        for(int k=0;k<BoneCount;++k) if(c.parts[k]) e.parts[k]=r.part(c.parts[k]);
                        if(!e.parts[Root].valid) continue;
                        auto prim=m.get<uint64_t>(c.parts[Root]+o("BasePart.Primitive"));
                        if(o.ini.contains("Primitive.AssemblyLinearVelocity")) m.read(prim+o("Primitive.AssemblyLinearVelocity"),e.velocity);
                        if(!finite(e.velocity)||length(e.velocity)>10000) e.velocity={};
                        if(c.r6){for(const auto& part:e.parts) if(part.valid) e.geometry.push_back(part);r6Joints(e);}
                        s.entities.push_back(std::move(e));
                    }
                    s.valid=true;s.sampled=sampled;s.status="Live data ready (read-only)";
                }else s.status="Validation failed: "+std::string(!pointer(visual)?"VisualEngine":!pointer(players)?"Players service":!pointer(local)?"LocalPlayer":!pointer(camera)?"CurrentCamera":"camera/view matrix")+". Join an experience or verify the exact-build profile/read access.";
            }
        }
        if(!s.valid) s.sampled=Clock::now();
        log(s.status);store_.publish(std::move(s),request.revision);
        sampleCostMs_=std::chrono::duration<double,std::milli>(Clock::now()-now).count();
        std::this_thread::sleep_until(now+std::chrono::milliseconds(1000/(foreground_.load()?hz_.load():10)));
    }
}
}
