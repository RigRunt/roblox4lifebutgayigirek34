#include "avatar.hpp"
#include <winhttp.h>
#include <wincodec.h>
#include <memory>
#include <stdexcept>
namespace ext {
namespace {
struct InternetHandle {HINTERNET value=nullptr;explicit InternetHandle(HINTERNET v):value(v){}~InternetHandle(){if(value) WinHttpCloseHandle(value);}InternetHandle(const InternetHandle&)=delete;};
std::vector<unsigned char> download(const std::wstring& url,size_t cap){
    URL_COMPONENTS parts{};parts.dwStructSize=sizeof parts;parts.dwHostNameLength=DWORD(-1);parts.dwUrlPathLength=DWORD(-1);parts.dwExtraInfoLength=DWORD(-1);
    if(!WinHttpCrackUrl(url.c_str(),DWORD(url.size()),0,&parts)||parts.nScheme!=INTERNET_SCHEME_HTTPS||parts.nPort!=443) throw std::runtime_error("Avatar URL rejected");
    std::wstring host(parts.lpszHostName,parts.dwHostNameLength);for(auto& c:host) if(c>=L'A'&&c<=L'Z') c=wchar_t(c-L'A'+L'a');
    if(!avatarHost(host)) throw std::runtime_error("Avatar host rejected");
    std::wstring path(parts.lpszUrlPath,parts.dwUrlPathLength);if(parts.dwExtraInfoLength) path.append(parts.lpszExtraInfo,parts.dwExtraInfoLength);
    InternetHandle session(WinHttpOpen(L"Nexra/PublicAvatar",WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0));
    if(!session.value) throw std::runtime_error("Avatar network unavailable");
    WinHttpSetTimeouts(session.value,3000,3000,3000,3000);
    InternetHandle connect(WinHttpConnect(session.value,host.c_str(),443,0));if(!connect.value) throw std::runtime_error("Avatar connection failed");
    InternetHandle request(WinHttpOpenRequest(connect.value,L"GET",path.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE));
    if(!request.value) throw std::runtime_error("Avatar request failed");
    DWORD redirect=WINHTTP_OPTION_REDIRECT_POLICY_NEVER;WinHttpSetOption(request.value,WINHTTP_OPTION_REDIRECT_POLICY,&redirect,sizeof redirect);
    if(!WinHttpSendRequest(request.value,WINHTTP_NO_ADDITIONAL_HEADERS,0,WINHTTP_NO_REQUEST_DATA,0,0,0)||!WinHttpReceiveResponse(request.value,nullptr)) throw std::runtime_error("Avatar HTTPS failed");
    DWORD code=0,bytes=sizeof code;WinHttpQueryHeaders(request.value,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,nullptr,&code,&bytes,nullptr);
    if(code!=200) throw std::runtime_error("Avatar service did not return an image");
    std::vector<unsigned char> body;unsigned char chunk[16384];auto deadline=Clock::now()+std::chrono::seconds(6);
    for(;;){if(Clock::now()>deadline) throw std::runtime_error("Avatar download timed out");DWORD count=0;if(!WinHttpReadData(request.value,chunk,sizeof chunk,&count)) throw std::runtime_error("Avatar download interrupted");
        if(!count) break;
        if(body.size()+count>cap) throw std::runtime_error("Avatar response too large");
        body.insert(body.end(),chunk,chunk+count);}
    return body;
}
std::wstring imageUrl(const std::vector<unsigned char>& body){
    std::string text(body.begin(),body.end());
    if(text.find("\"Completed\"")==std::string::npos) throw std::runtime_error("Avatar still pending / unavailable");
    auto pos=text.find("\"imageUrl\"");if(pos==std::string::npos) throw std::runtime_error("Avatar image URL missing");
    pos=text.find(':',pos);if(pos==std::string::npos) throw std::runtime_error("Invalid avatar metadata");
    pos=text.find('"',pos);if(pos==std::string::npos) throw std::runtime_error("Invalid avatar metadata");
    std::wstring result;
    for(++pos;pos<text.size();++pos){char c=text[pos];if(c=='"') break;
        if(c=='\\'){if(++pos>=text.size()||text[pos]!='/') throw std::runtime_error("Unsupported avatar URL encoding");c='/';}
        if(static_cast<unsigned char>(c)<32||static_cast<unsigned char>(c)>126||result.size()>=2048) throw std::runtime_error("Invalid avatar URL");
        result.push_back(wchar_t(c));
    }
    if(result.empty()||pos>=text.size()) throw std::runtime_error("Invalid avatar URL");
    return result;
}
template<class T> struct Com {T* value=nullptr;~Com(){if(value) value->Release();}T** address(){return &value;}};
AvatarPixels decode(const std::vector<unsigned char>& body){
    AvatarPixels image;Com<IWICImagingFactory> factory;Com<IWICStream> stream;Com<IWICBitmapDecoder> decoder;Com<IWICBitmapFrameDecode> frame;Com<IWICFormatConverter> converter;
    auto ok=[](HRESULT code){if(FAILED(code)) throw std::runtime_error("Avatar PNG decode failed");};
    ok(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(factory.address())));
    ok(factory.value->CreateStream(stream.address()));ok(stream.value->InitializeFromMemory(const_cast<BYTE*>(body.data()),DWORD(body.size())));
    ok(factory.value->CreateDecoderFromStream(stream.value,nullptr,WICDecodeMetadataCacheOnDemand,decoder.address()));
    ok(decoder.value->GetFrame(0,frame.address()));UINT width=0,height=0;ok(frame.value->GetSize(&width,&height));
    if(width<1||height<1||width>1024||height>1024) throw std::runtime_error("Avatar dimensions rejected");
    ok(factory.value->CreateFormatConverter(converter.address()));
    ok(converter.value->Initialize(frame.value,GUID_WICPixelFormat32bppRGBA,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom));
    image.width=int(width);image.height=int(height);image.rgba.resize(size_t(width)*height*4);
    ok(converter.value->CopyPixels(nullptr,width*4,UINT(image.rgba.size()),image.rgba.data()));return image;
}
}
void AvatarService::request(uint64_t user,bool enabled){
    std::lock_guard<std::mutex> lock(mutex_);enabled=enabled&&user>0&&user<1000000000000ULL;
    if(requested_==user&&enabled_==enabled) return;
    requested_=user;enabled_=enabled;pending_=true;pixels_=AvatarPixels{};pixels_.serial=++serial_;pixels_.user=user;
    pixels_.status=enabled?"Loading public avatar...":"Bacon-hair fallback";condition_.notify_all();
}
AvatarPixels AvatarService::pixels(uint64_t after){std::lock_guard<std::mutex> lock(mutex_);return pixels_.serial==after?AvatarPixels{}:pixels_;}
void AvatarService::run(){
    HRESULT com=CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    for(;;){uint64_t user=0;bool enabled=false;
        {std::unique_lock<std::mutex> lock(mutex_);condition_.wait(lock,[&]{return stop_||pending_;});if(stop_) break;pending_=false;user=requested_;enabled=enabled_;}
        if(!enabled) continue;
        AvatarPixels result;
        try {auto metadata=download(L"https://thumbnails.roblox.com/v1/users/avatar?userIds="+std::to_wstring(user)+L"&size=420x420&format=Png&isCircular=false",65536);
            auto png=download(imageUrl(metadata),4*1024*1024);result=decode(png);result.status="Public Roblox avatar";
        }catch(const std::exception& e){result.status=std::string("Bacon-hair fallback: ")+e.what();}
        {std::lock_guard<std::mutex> lock(mutex_);if(!stop_&&enabled_&&requested_==user){result.user=user;result.serial=++serial_;pixels_=std::move(result);}}
    }
    if(SUCCEEDED(com)) CoUninitialize();
}
AvatarView AvatarTexture::update(AvatarService& service,ID3D11Device* device,uint64_t user,bool enabled){
    service.request(user,enabled);
    if(user!=user_){reset();user_=user;}
    if(!enabled&&texture_){texture_->Release();texture_=nullptr;width_=height_=0;}
    auto image=service.pixels(serial_);
    if(image.serial){
        serial_=image.serial;status_=image.status;
        if(texture_){texture_->Release();texture_=nullptr;}
        width_=height_=0;
        if(enabled&&image.user==user&&!image.rgba.empty()&&device){
            D3D11_TEXTURE2D_DESC description{};description.Width=image.width;description.Height=image.height;description.MipLevels=1;description.ArraySize=1;
            description.Format=DXGI_FORMAT_R8G8B8A8_UNORM;description.SampleDesc.Count=1;description.Usage=D3D11_USAGE_IMMUTABLE;description.BindFlags=D3D11_BIND_SHADER_RESOURCE;
            D3D11_SUBRESOURCE_DATA data{};data.pSysMem=image.rgba.data();data.SysMemPitch=image.width*4;ID3D11Texture2D* texture=nullptr;
            if(SUCCEEDED(device->CreateTexture2D(&description,&data,&texture))){auto result=device->CreateShaderResourceView(texture,nullptr,&texture_);texture->Release();
                if(SUCCEEDED(result)){width_=image.width;height_=image.height;}else status_="Bacon-hair fallback: GPU texture failed";}
        }
    }
    return {texture_,width_,height_,status_};
}
}
