#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <d3d11.h>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>
#include "features.hpp"
namespace ext {
struct AvatarPixels {uint64_t user=0,serial=0;int width=0,height=0;std::vector<unsigned char> rgba;std::string status="Bacon-hair fallback";};
class AvatarService {
    std::mutex mutex_;std::condition_variable condition_;bool stop_=false,enabled_=false,pending_=false;
    uint64_t requested_=0,serial_=0;AvatarPixels pixels_;std::thread thread_;
    void run();
public:
    AvatarService():thread_(&AvatarService::run,this){}
    ~AvatarService(){ {std::lock_guard<std::mutex> lock(mutex_);stop_=true;}condition_.notify_all();thread_.join();}
    void request(uint64_t user,bool enabled);
    AvatarPixels pixels(uint64_t afterSerial);
};
struct AvatarView {ID3D11ShaderResourceView* texture=nullptr;int width=0,height=0;std::string status="Bacon-hair fallback";};
class AvatarTexture {
    ID3D11ShaderResourceView* texture_=nullptr;uint64_t serial_=0,user_=0;int width_=0,height_=0;
    std::string status_="Bacon-hair fallback";
public:
    ~AvatarTexture(){reset();}
    void reset(){if(texture_) texture_->Release();texture_=nullptr;serial_=0;user_=0;width_=height_=0;}
    AvatarView update(AvatarService& service,ID3D11Device* device,uint64_t user,bool enabled);
};
}
