#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include "core.hpp"
#include "settings.hpp"
#include "state.hpp"
#include <atomic>
#include <filesystem>
#include <thread>

namespace ext {
class Provider {
public:
    enum Mode { Live=0, Demo=1 };
    explicit Provider(std::filesystem::path folder);
    ~Provider();
    Provider(const Provider&)=delete;
    Provider& operator=(const Provider&)=delete;
    Snapshot snapshot() const {return store_.snapshot();}
    std::shared_ptr<const Snapshot> sharedSnapshot() const {return store_.sharedSnapshot();}
    void mode(Mode mode) {store_.setMode(int(mode));}
    Mode mode() const {return Mode(store_.mode());}
    void reload() {store_.reload();}
    uint64_t revision() const {return store_.revision();}
    void performance(int hz,int cacheMs){hz_=std::clamp(hz,10,60);cacheMs_=std::clamp(cacheMs,250,2500);}
    void foreground(bool value){foreground_=value;}
    double sampleCostMs() const{return sampleCostMs_.load();}
private:
    void run();
    std::filesystem::path folder_;
    SnapshotStore store_;
    std::atomic<bool> stop_{false},foreground_{true};
    std::atomic<int> hz_{30},cacheMs_{900};
    std::atomic<double> sampleCostMs_{0};
    std::thread thread_;
};
}
