#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shellapi.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <thread>
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"
#include "provider.hpp"
#include "renderer.hpp"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
namespace {
constexpr wchar_t WindowClass[]=L"NexraExternalOverlay";
constexpr UINT RevealMenu=WM_APP+1;
ID3D11Device* device=nullptr;
ID3D11DeviceContext* context=nullptr;
IDXGISwapChain* chain=nullptr;
ID3D11RenderTargetView* renderTarget=nullptr;
UINT resizeW=0,resizeH=0;
bool menuVisible=true,revealRequested=false;
ext::Bounds menuBounds{};
void releaseTarget(){if(renderTarget){renderTarget->Release();renderTarget=nullptr;}}
void releaseDevice(){
    if(context) context->ClearState();
    releaseTarget();
    if(chain) chain->Release();
    if(context) context->Release();
    if(device) device->Release();
    chain=nullptr;context=nullptr;device=nullptr;
}
void makeTarget(){
    ID3D11Texture2D* buffer=nullptr;
    if(!chain||FAILED(chain->GetBuffer(0,IID_PPV_ARGS(&buffer)))) throw std::runtime_error("DX11 back buffer was unavailable");
    auto result=device->CreateRenderTargetView(buffer,nullptr,&renderTarget);buffer->Release();
    if(FAILED(result)) throw std::runtime_error("DX11 render target creation failed");
}
bool createDevice(HWND window){
    releaseDevice();
    DXGI_SWAP_CHAIN_DESC desc{};desc.BufferCount=2;desc.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;desc.OutputWindow=window;desc.SampleDesc.Count=1;
    desc.Windowed=TRUE;desc.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
    const D3D_FEATURE_LEVEL levels[]{D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_0};D3D_FEATURE_LEVEL selected{};
    auto attempt=[&](D3D_DRIVER_TYPE driver){
        return D3D11CreateDeviceAndSwapChain(nullptr,driver,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,
            levels,2,D3D11_SDK_VERSION,&desc,&chain,&device,&selected,&context);
    };
    auto result=attempt(D3D_DRIVER_TYPE_HARDWARE);
    if(FAILED(result)){releaseDevice();result=attempt(D3D_DRIVER_TYPE_WARP);}
    if(FAILED(result)){releaseDevice();return false;}
    makeTarget();return true;
}
LRESULT CALLBACK windowProc(HWND hwnd,UINT msg,WPARAM wp,LPARAM lp){
    if(menuVisible&&ImGui::GetCurrentContext()&&ImGui_ImplWin32_WndProcHandler(hwnd,msg,wp,lp)) return TRUE;
    switch(msg){
        case RevealMenu:revealRequested=true;return 0;
        case WM_SIZE:if(wp!=SIZE_MINIMIZED){resizeW=LOWORD(lp);resizeH=HIWORD(lp);}return 0;
        case WM_ERASEBKGND:return 1;
        case WM_MOUSEACTIVATE:return menuVisible?MA_ACTIVATE:MA_NOACTIVATE;
        case WM_NCHITTEST:{
            if(!menuVisible) return HTTRANSPARENT;
            if(ImGui::GetCurrentContext()&&ImGui::GetIO().WantCaptureMouse) return HTCLIENT;
            POINT point{LONG(short(LOWORD(lp))),LONG(short(HIWORD(lp)))};ScreenToClient(hwnd,&point);
            if(point.x<menuBounds.left||point.x>menuBounds.right||point.y<menuBounds.top||point.y>menuBounds.bottom) return HTTRANSPARENT;
            return HTCLIENT;
        }
        case WM_SYSCOMMAND:if((wp&0xfff0)==SC_KEYMENU) return 0;break;
        case WM_DESTROY:PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}
void inputStyle(HWND hwnd,bool interactive){
    LONG_PTR style=WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_LAYERED;
    if(!interactive) style|=WS_EX_TRANSPARENT|WS_EX_NOACTIVATE;
    SetWindowLongPtrW(hwnd,GWL_EXSTYLE,style);
    SetWindowPos(hwnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_FRAMECHANGED);
}
std::filesystem::path executableFolder(){
    std::wstring path(32768,L'\0');DWORD length=GetModuleFileNameW(nullptr,path.data(),DWORD(path.size()));
    if(!length||length>=path.size()) throw std::runtime_error("Cannot locate executable folder");
    path.resize(length);return std::filesystem::path(path).parent_path();
}
int aimKey(int mode){const int keys[]{VK_RBUTTON,VK_LBUTTON,VK_MENU,VK_XBUTTON1};return keys[std::clamp(mode,0,3)];}
bool gameFocused(HWND target,DWORD expectedPid){
    if(!target||!expectedPid||!IsWindow(target)||IsIconic(target)) return false;
    DWORD actualPid=0;GetWindowThreadProcessId(target,&actualPid);
    return actualPid==expectedPid&&GetAncestor(GetForegroundWindow(),GA_ROOT)==GetAncestor(target,GA_ROOT);
}
struct AppResources {
    HINSTANCE instance;
    HANDLE singleton=nullptr;
    HWND window=nullptr;
    bool registeredClass=false,insertHotkey=false,endHotkey=false,win32Ready=false,dxReady=false;
    explicit AppResources(HINSTANCE value):instance(value){}
    void resetGraphics(){
        if(dxReady){ImGui_ImplDX11_Shutdown();dxReady=false;}
        releaseDevice();
        if(!createDevice(window)) throw std::runtime_error("DirectX 11 device could not be created");
        dxReady=ImGui_ImplDX11_Init(device,context);
        if(!dxReady) throw std::runtime_error("DirectX 11 UI backend could not be initialized");
    }
    ~AppResources(){
        if(dxReady) ImGui_ImplDX11_Shutdown();
        if(win32Ready) ImGui_ImplWin32_Shutdown();
        if(ImGui::GetCurrentContext()) ImGui::DestroyContext();
        releaseDevice();
        if(insertHotkey) UnregisterHotKey(window,1);
        if(endHotkey) UnregisterHotKey(window,2);
        if(window&&IsWindow(window)) DestroyWindow(window);
        if(registeredClass) UnregisterClassW(WindowClass,instance);
        if(singleton) CloseHandle(singleton);
    }
};
struct InputController {
    enum Result { Sent, NoMovement, Blocked, Failed };
    ext::RelativeAccumulator remainder;
    void reset(){remainder.reset();}
    Result send(ext::Vec2 step,ext::Vec2 cursor,const ext::AimOptions& options,HWND target,DWORD pid,bool requireAimKey=true,bool requireRecoil=false){
        if(!ext::finite(step)||!ext::finite(cursor)||!gameFocused(target,pid)||(requireRecoil&&((GetAsyncKeyState(VK_LBUTTON)&0x8000)==0||(GetAsyncKeyState(VK_RBUTTON)&0x8000)==0))||(requireAimKey&&(GetAsyncKeyState(aimKey(options.activation))&0x8000)==0)||(!requireAimKey&&((GetAsyncKeyState(VK_LBUTTON)&0x8000)==0||(GetAsyncKeyState(VK_RBUTTON)&0x8000)==0))){reset();return Blocked;}
        if(options.inputMode==1){
            POINT point{LONG(std::lround(cursor.x+step.x)),LONG(std::lround(cursor.y+step.y))};
            RECT bounds{};
            if(!GetClientRect(target,&bounds)||bounds.right<=0||bounds.bottom<=0){reset();return Failed;}
            if(!ext::onScreen(cursor,float(bounds.right),float(bounds.bottom))){reset();return Blocked;}
            point.x=std::clamp(point.x,LONG(0),bounds.right-1);point.y=std::clamp(point.y,LONG(0),bounds.bottom-1);
            POINT original{};
            if(!ClientToScreen(target,&point)||!GetCursorPos(&original)){reset();return Failed;}
            if(original.x==point.x&&original.y==point.y) return NoMovement;
            return SetCursorPos(point.x,point.y)?Sent:Failed;
        }
        auto output=remainder.quantize(step,options.maxStep);
        if(output[0]==0&&output[1]==0) return NoMovement;
        INPUT input{};input.type=INPUT_MOUSE;input.mi.dx=output[0];input.mi.dy=output[1];input.mi.dwFlags=MOUSEEVENTF_MOVE;
        if(SendInput(1,&input,sizeof input)!=1){reset();return Failed;}
        return Sent;
    }
};
void loadFont(const std::filesystem::path& path,ImGuiIO& io){
    std::ifstream file(path,std::ios::binary|std::ios::ate);
    if(file){
        auto length=file.tellg();
        if(length>=12&&length<10*1024*1024){
            auto* data=static_cast<unsigned char*>(ImGui::MemAlloc(size_t(length)));
            if(data){
                file.seekg(0);
                bool valid=bool(file.read(reinterpret_cast<char*>(data),length));
                valid=valid&&data[0]==0&&data[1]==1&&data[2]==0&&data[3]==0;
                if(valid){
                    size_t tables=(size_t(data[4])<<8)|data[5];valid=tables>0&&tables<128&&12+tables*16<=size_t(length);
                    for(size_t k=0;valid&&k<tables;++k){
                        auto read=[&](size_t offset){return (uint64_t(data[offset])<<24)|(uint64_t(data[offset+1])<<16)|(uint64_t(data[offset+2])<<8)|data[offset+3];};
                        size_t offset=12+k*16;uint64_t start=read(offset+8),bytes=read(offset+12);
                        valid=start<=uint64_t(length)&&bytes<=uint64_t(length)-start;
                    }
                }
                if(valid) io.Fonts->AddFontFromMemoryTTF(data,int(length),15.0f);
                else ImGui::MemFree(data);
            }
        }
    }
    if(io.Fonts->Fonts.empty()){ImFontConfig font;font.SizePixels=15;io.Fonts->AddFontDefault(&font);}
}
int run(HINSTANCE instance){
    SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    auto folder=executableFolder();AppResources resources(instance);
    resources.singleton=CreateMutexW(nullptr,FALSE,L"Local\\NexraExternal.SingleInstance");
    if(!resources.singleton) throw std::runtime_error("Could not create application instance guard");
    if(GetLastError()==ERROR_ALREADY_EXISTS){
        if(HWND existing=FindWindowW(WindowClass,nullptr)) PostMessageW(existing,RevealMenu,0,0);
        return 0;
    }
    ext::Settings cfg;cfg.load(folder/"settings.ini");cfg.clamp();ext::Provider provider(folder);
    int argc=0;auto argv=CommandLineToArgvW(GetCommandLineW(),&argc);bool demo=false;
    for(int k=1;argv&&k<argc;++k) if(std::wstring(argv[k])==L"--demo") demo=true;
    if(argv) LocalFree(argv);
    if(demo) provider.mode(ext::Provider::Demo);
    ImGui_ImplWin32_EnableDpiAwareness();HWND lastForeground=GetForegroundWindow();
    WNDCLASSEXW wc{};wc.cbSize=sizeof wc;
    wc.style=CS_HREDRAW|CS_VREDRAW; // Layered windows cannot use CS_CLASSDC or CS_OWNDC.
    wc.lpfnWndProc=windowProc;wc.hInstance=instance;wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.lpszClassName=WindowClass;
    if(!RegisterClassExW(&wc)) throw std::runtime_error("Window class registration failed");
    resources.registeredClass=true;
    int width=GetSystemMetrics(SM_CXSCREEN),height=GetSystemMetrics(SM_CYSCREEN);
    if(width<=0||height<=0) throw std::runtime_error("Desktop display dimensions were unavailable");
    HWND hwnd=CreateWindowExW(WS_EX_TOPMOST|WS_EX_LAYERED|WS_EX_TOOLWINDOW,WindowClass,L"Nexra External",
        WS_POPUP,0,0,width,height,nullptr,nullptr,instance,nullptr);
    if(!hwnd) throw std::runtime_error("Overlay window creation failed");
    resources.window=hwnd;
    resources.insertHotkey=RegisterHotKey(hwnd,1,MOD_NOREPEAT,VK_INSERT)!=FALSE;
    resources.endHotkey=RegisterHotKey(hwnd,2,MOD_NOREPEAT,VK_END)!=FALSE;
    if(!SetLayeredWindowAttributes(hwnd,0,255,LWA_ALPHA)) throw std::runtime_error("Layered-window initialization failed");
    MARGINS margins{-1,-1,-1,-1};DwmExtendFrameIntoClientArea(hwnd,&margins);ImGui_ImplWin32_EnableAlphaCompositing(hwnd);
    if(!createDevice(hwnd)) throw std::runtime_error("DirectX 11 was unavailable");
    ShowWindow(hwnd,SW_SHOW);UpdateWindow(hwnd);
    IMGUI_CHECKVERSION();ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.LogFilename=nullptr;
    loadFont(folder/"assets"/"Inter.ttf",io);ext::setTheme();
    resources.win32Ready=ImGui_ImplWin32_Init(hwnd);
    resources.dxReady=ImGui_ImplDX11_Init(device,context);
    if(!resources.win32Ready||!resources.dxReady) throw std::runtime_error("UI backend initialization failed");
    ext::AvatarService avatarService;ext::AvatarTexture avatarTexture;
    InputController input;bool running=true,lastInsert=false,lastEnd=false;uint64_t previous=0,steeredId=0,acquiredId=0;
    auto acquiredSince=ext::Clock::now(),burstStart=ext::Clock::now();bool burst=false;
    std::string patternText;std::vector<ext::RecoilSegment> pattern;
    auto previousFrame=ext::Clock::now();float fps=0;
    int oldX=0,oldY=0,oldW=width,oldH=height;
    std::string inputStatus="Disabled",recoilStatus="Disabled";
    while(running){
        auto frameStart=ext::Clock::now();float dt=std::chrono::duration<float>(frameStart-previousFrame).count();previousFrame=frameStart;
        if(dt>0&&std::isfinite(dt)) fps=fps==0?1/dt:fps*.94f+(1/dt)*.06f;
        bool menuRequested=false,exitRequested=false;MSG message{};
        while(PeekMessageW(&message,nullptr,0,0,PM_REMOVE)){
            if(message.message==WM_HOTKEY){if(message.wParam==1) menuRequested=true;if(message.wParam==2) exitRequested=true;continue;}
            TranslateMessage(&message);DispatchMessageW(&message);if(message.message==WM_QUIT) running=false;
        }
        if(!running||exitRequested) break;
        auto shared=provider.sharedSnapshot();const auto& snapshot=*shared;HWND target=reinterpret_cast<HWND>(snapshot.targetWindow);
        SHORT insertState=resources.insertHotkey?0:GetAsyncKeyState(VK_INSERT),endState=resources.endHotkey?0:GetAsyncKeyState(VK_END);
        bool insert=(insertState&0x8000)!=0,end=(endState&0x8000)!=0;
        if(revealRequested||menuRequested||(!resources.insertHotkey&&!lastInsert&&(insert||(insertState&1)))){
            bool next=revealRequested?true:!menuVisible;revealRequested=false;
            if(next&&!menuVisible) lastForeground=GetForegroundWindow();
            menuVisible=next;inputStyle(hwnd,menuVisible);input.reset();previous=steeredId=0;
            if(menuVisible){ShowWindow(hwnd,SW_SHOW);SetForegroundWindow(hwnd);}
            else if(IsWindow(target)) SetForegroundWindow(target);
            else if(lastForeground!=hwnd&&IsWindow(lastForeground)) SetForegroundWindow(lastForeground);
        }
        if(!resources.endHotkey&&!lastEnd&&(end||(endState&1))) break;
        lastInsert=insert;lastEnd=end;cfg.clamp();provider.performance(cfg.readerHz,cfg.cacheMs);
        int x=0,y=0;width=GetSystemMetrics(SM_CXSCREEN);height=GetSystemMetrics(SM_CYSCREEN);
        bool live=provider.mode()==ext::Provider::Live;
        DWORD actualPid=0;if(target) GetWindowThreadProcessId(target,&actualPid);
        bool gameAvailable=live&&snapshot.pid&&actualPid==snapshot.pid&&IsWindow(target)&&!IsIconic(target);
        if(gameAvailable&&!menuVisible){
            RECT rectangle{};POINT position{};
            if(GetClientRect(target,&rectangle)&&ClientToScreen(target,&position)&&rectangle.right>0&&rectangle.bottom>0){
                x=position.x;y=position.y;width=rectangle.right;height=rectangle.bottom;
            }else gameAvailable=false;
        }
        if(width<=0||height<=0){width=oldW;height=oldH;}
        bool focused=gameAvailable&&gameFocused(target,snapshot.pid),visible=menuVisible||!live||focused;
        if(visible&&!IsWindowVisible(hwnd)) ShowWindow(hwnd,SW_SHOWNA);
        if(!visible&&IsWindowVisible(hwnd)) ShowWindow(hwnd,SW_HIDE);
        RECT actual{};GetWindowRect(hwnd,&actual);
        if(x!=oldX||y!=oldY||width!=oldW||height!=oldH||actual.left!=x||actual.top!=y||actual.right-actual.left!=width||actual.bottom-actual.top!=height){
            SetWindowPos(hwnd,HWND_TOPMOST,x,y,width,height,SWP_NOACTIVATE);oldX=x;oldY=y;oldW=width;oldH=height;
        }
        if(resizeW&&resizeH){
            context->OMSetRenderTargets(0,nullptr,nullptr);context->ClearState();releaseTarget();
            auto result=chain->ResizeBuffers(0,resizeW,resizeH,DXGI_FORMAT_UNKNOWN,0);resizeW=resizeH=0;
            if(result==DXGI_ERROR_DEVICE_REMOVED||result==DXGI_ERROR_DEVICE_RESET) {avatarTexture.reset();resources.resetGraphics();}
            else {if(FAILED(result)) throw std::runtime_error("DirectX resize failed");makeTarget();}
        }
        POINT point{};bool cursorKnown=GetCursorPos(&point)&&ScreenToClient(hwnd,&point);
        ext::Vec2 cursor{float(point.x),float(point.y)};bool held=(GetAsyncKeyState(aimKey(cfg.aim.activation))&0x8000)!=0;
        bool left=(GetAsyncKeyState(VK_LBUTTON)&0x8000)!=0,right=(GetAsyncKeyState(VK_RBUTTON)&0x8000)!=0;
        provider.foreground(focused||menuVisible);
        bool current=snapshot.revision==provider.revision(),fresh=ext::fresh(snapshot,ext::Clock::now())&&current;
        ext::Vec2 fovOrigin=cfg.aim.origin==0?ext::Vec2{width/2.f,height/2.f}:cursor;
        std::optional<ext::Target> selected;
        if(cfg.aim.enabled&&fresh&&cursorKnown&&(!menuVisible||!live)) selected=ext::selectTarget(snapshot,cfg.aim,fovOrigin,float(width),float(height),held?previous:0);
        if(!held||!selected||menuVisible||!focused) previous=0;else previous=selected->id;
        if(!selected||!held||menuVisible||!focused){acquiredId=0;acquiredSince=frameStart;}
        else if(acquiredId!=selected->id){acquiredId=selected->id;acquiredSince=frameStart;}
        bool acquired=selected&&std::chrono::duration<double,std::milli>(frameStart-acquiredSince).count()>=cfg.aim.switchDelayMs;
        bool allowed=acquired&&current&&cursorKnown&&ext::allowMouseOutput(snapshot,cfg.aim,live,menuVisible,focused,held,bool(selected),ext::Clock::now());
        if(!cfg.aim.enabled) inputStatus="Disabled";
        else if(snapshot.demo||!live) inputStatus="Demo: selection preview only; mouse output disabled";
        else if(menuVisible) inputStatus="Paused: menu is open";
        else if(!fresh) inputStatus="Paused: no fresh, validated live data";
        else if(!focused) inputStatus="Paused: Roblox is not the foreground window";
        else if(!cursorKnown) inputStatus="Paused: cursor position unavailable";
        else if(!held) inputStatus="Ready: hold the configured aim key";
        else if(!selected) inputStatus="No eligible target inside the FOV";
        else if(!acquired) inputStatus="Acquiring target: delay active";
        else if(allowed){
            inputStatus="Tracking eligible target";
        }else inputStatus="Paused: input conditions changed";
        bool recoilAllowed=current&&cursorKnown&&ext::allowRecoilOutput(snapshot,cfg.recoil,live,menuVisible,focused,left,right,ext::Clock::now());
        if(cfg.aim.enabled&&cfg.aim.inputMode!=0) recoilAllowed=false;
        if(patternText!=cfg.recoil.pattern){patternText=cfg.recoil.pattern;pattern=ext::parsePattern(patternText).value_or(std::vector<ext::RecoilSegment>{});}
        if(!recoilAllowed) burst=false;else if(!burst){burst=true;burstStart=frameStart;}
        ext::Vec2 combined{};
        if(allowed&&selected){
            if(steeredId!=selected->id) input.reset();
            steeredId=selected->id;
            ext::Vec2 origin=cfg.aim.inputMode==0?ext::Vec2{width/2.f,height/2.f}:cursor;
            combined=ext::aimStep(selected->screen,origin,cfg.aim,dt);
        }
        if(recoilAllowed){auto recoil=ext::recoilStep(cfg.recoil,pattern,std::chrono::duration<double,std::milli>(frameStart-burstStart).count(),dt);combined.x+=recoil.x;combined.y+=recoil.y;}
        if(!cfg.recoil.enabled) recoilStatus="Disabled";
        else if(!live||snapshot.demo) recoilStatus="Demo: no mouse output";
        else if(cfg.aim.enabled&&cfg.aim.inputMode!=0) recoilStatus="Paused: combined aim requires relative mode";
        else recoilStatus=recoilAllowed?"Compensating while RMB + LMB held":"Paused: requires fresh live data, focus, hidden menu, RMB + LMB";
        if(allowed||recoilAllowed){
            ext::AimOptions output=cfg.aim;if(!allowed){output.inputMode=0;output.maxStep=cfg.recoil.maxStep;}
            auto result=input.send(combined,cursor,output,target,snapshot.pid,allowed,recoilAllowed);
            switch(result){
                case InputController::Sent:if(allowed) inputStatus="Mouse command sent; game acceptance unverified";if(recoilAllowed) recoilStatus="Compensation command sent; no spread cancellation";break;
                case InputController::NoMovement:if(allowed) inputStatus="Tracking: deadzone / sub-pixel movement";if(recoilAllowed) recoilStatus="Tracking burst: delay / sub-pixel / pattern complete";break;
                case InputController::Blocked:inputStatus="Paused: input conditions changed before output";recoilStatus="Paused: input conditions changed";break;
                case InputController::Failed:inputStatus="Windows mouse output failed";recoilStatus="Windows mouse output failed";break;
            }
        }else {input.reset();steeredId=0;}
        if(!visible){std::this_thread::sleep_for(std::chrono::milliseconds(30));continue;}
        ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
        if(!menuVisible) ext::drawOverlay(snapshot,cfg,float(width),float(height),cursor,selected,held,fps);
        if(menuVisible){
            auto image=avatarTexture.update(avatarService,device,snapshot.demo?0:snapshot.localUserId,cfg.onlineAvatar);
            ext::drawMenu(cfg,provider,snapshot,folder,inputStatus,recoilStatus,image,running);
            auto size=ext::menuSize(io.DisplaySize);
            menuBounds={(io.DisplaySize.x-size.x)/2,(io.DisplaySize.y-size.y)/2,(io.DisplaySize.x+size.x)/2,(io.DisplaySize.y+size.y)/2};
        }
        ImGui::Render();const float clear[]{0,0,0,0};context->OMSetRenderTargets(1,&renderTarget,nullptr);
        context->ClearRenderTargetView(renderTarget,clear);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        auto result=chain->Present(cfg.vsync?1:0,0);
        if(result==DXGI_ERROR_DEVICE_REMOVED||result==DXGI_ERROR_DEVICE_RESET){input.reset();avatarTexture.reset();resources.resetGraphics();}
        else if(FAILED(result)) throw std::runtime_error("DirectX presentation failed");
        if(result==DXGI_STATUS_OCCLUDED) std::this_thread::sleep_for(std::chrono::milliseconds(30));
        else {
            int limit=focused||(!live&&!menuVisible)?cfg.frameCap:std::min(cfg.frameCap,cfg.idleFps);
            if(!cfg.vsync||(!focused&&menuVisible)) std::this_thread::sleep_until(frameStart+std::chrono::microseconds(1000000/limit));
        }
    }
    cfg.save(folder/"settings.ini");return 0;
}
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int){
    try{return run(instance);}catch(const std::exception& exception){
        MessageBoxA(nullptr,exception.what(),"Nexra External",MB_OK|MB_ICONERROR);return 1;
    }
}
