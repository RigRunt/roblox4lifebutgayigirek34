@echo off
cd /d "%~dp0"
if not exist RobloxExternal.exe (
  echo RobloxExternal.exe is missing. Run build.bat first.
  pause
  exit /b 1
)
start "" "%~dp0RobloxExternal.exe"
