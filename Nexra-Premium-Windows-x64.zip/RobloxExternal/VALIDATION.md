# Validation — Premium / performance 1.1.0 — 2026-10-01

## Binary

Windows x64 GUI, C++17 / Win32 / DirectX 11. MinGW-w64 GCC 14.0, CMake Release, static C++/thread runtime. Complete application and new avatar worker compiled and linked without warnings.

Final EXE SHA-256: `5e3a8323a31173dd13bf82f8b14511bd715da246ea5ec1194b905d307a915f7c`.

This is a newly compiled executable matching the source in this archive, not the previous profile-only delivery binary. The manifest remains asInvoker/per-monitor DPI.

## Tests

- Linux GCC 14.2: **131 assertions pass**, direct build and CMake/CTest (1/1).
- **10,000 randomized integer-movement cases** per core run stay bounded.
- AddressSanitizer + UndefinedBehaviorSanitizer run: 131 assertions/randomized cases pass with no reported findings.
- Windows provider target: **59 assertions pass under Wine 10**. No Roblox process is needed for those worker/demo/reload/lifecycle tests.

New coverage: radar axes/camera rotation/edge mapping/square clamp/invalid inputs; recoil delays and exact integration across pattern boundaries, pattern completion and input bounds; demo/fire/aim gates; avatar hostname allowlist; new config sanitization/round-trip; immutable snapshot sharing/lifetime; minimum/lowest-health targeting, deadzone, axis disabling and rate limits.

Earlier eight numeric/configuration regressions remain covered. These tests do not validate live Roblox internals or every Windows API condition.

## GUI smoke tests

Actual Windows executable under Wine 10 / Xvfb 1280×900, software graphics translation:

- Refined menu and bundled Inter rendered successfully.
- Bacon-hair fallback, explicit `Demo account` bottom username and avatar-stage panel inspected.
- Recoil page rendered and enabled; aim controls and radar could be enabled.
- Radar rendered with rings, heading label, center triangle and player markers.
- Insert show/hide worked; seven simulated entities, FOV and selected-target line visible.
- Holding RMB + LMB in Demo for one second kept cursor at `(630,448)`; no demo mouse movement.
- The post-polish final EXE was relaunched successfully and exited 0 on End.
- `ui-preview.png` is a genuine crop from the final EXE, not generated artwork.

A standalone Windows avatar-worker probe under Wine successfully fetched and decoded the official public avatar for test user ID 1: 420×420 RGBA, 705,600 bytes. Host allowlisting was unit tested. Live local-user ID detection and the native-Windows image path remain unverified.

## Optimization measurement

Linux synthetic microbenchmark, GCC -O2: 128 entities with names/geometry, 20,000 snapshot reads. Deep-copy accessor: **2164.95 ms**. Shared immutable accessor: **0.170588 ms**.

This isolates snapshot-access work and demonstrates that the render path no longer deep-copies all entities. It is not an overall application or Roblox FPS result. Reader/background caps are implemented; no percentage FPS improvement is promised.

## Imports/transparency

Final import inspection before the last polish rebuild: d3d11, D3DCOMPILER_47, dwmapi, GDI32, KERNEL32, msvcrt, ole32, SHELL32, USER32, WINHTTP. Static MinGW runtime; WIC interfaces are created through COM. The last polish changes did not add libraries.

There are no game-memory writes, injected DLL, driver or remote-thread calls. Optional public-avatar HTTPS requests are a new feature, not telemetry or an updater. No game data/login credentials are uploaded.

## Not verified

Current live profile, real local username/UserId reads, avatar network responses on native Windows, real camera yaw/radar alignment, real mouse/camera response, native MSVC execution, every monitor/DPI/GPU/driver condition, anti-cheat/account outcomes.

Profile target remains `version-02c37bc51a384b8f`, `RuntimeVerified=false`. Optional UserId/Camera.Rotation fields agree with the pinned numeric source but are not live-verified here. Matching versions are necessary, not proof of compatibility. Speed/fly/spread cancellation were not implemented or claimed. Passing these checks is not a zero-bug guarantee.
