#include "provider.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <thread>
using namespace ext;
int checks=0;
void check(bool result,const char* label){++checks;if(!result) throw std::runtime_error(label);}
Snapshot await(Provider& provider,bool demo){
    auto deadline=Clock::now()+std::chrono::seconds(3);
    while(Clock::now()<deadline){
        auto frame=provider.snapshot();
        if(frame.valid&&frame.demo==demo) return frame;
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    throw std::runtime_error("demo provider did not become ready");
}
int wmain(){try{
    auto folder=std::filesystem::temp_directory_path()/("nexra-provider-"+std::to_string(Clock::now().time_since_epoch().count()));
    std::filesystem::create_directory(folder);
    {
        Provider provider(folder);
        provider.mode(Provider::Demo);auto frame=await(provider,true);
        check(frame.entities.size()==7,"demo entities created without an offset profile");
        check(frame.pid==0&&frame.targetWindow==0,"demo never masquerades as a live process");
        check(validViewMatrix(frame.view),"demo view matrix valid");
        check(frame.entities[0].parts[Root].valid,"demo rig populated");
        for(int k=0;k<25;++k){
            auto previous=frame.revision;provider.reload();auto after=provider.snapshot();
            check(after.revision>previous,"reload revision increases synchronously");
            check(!after.valid||after.revision>previous,"reload cannot return an old valid frame");
            frame=await(provider,true);
        }
        auto revision=frame.revision;provider.mode(Provider::Live);auto after=provider.snapshot();
        check(!after.valid&&!after.demo&&after.revision>revision,"live switch invalidates demo synchronously");
        std::this_thread::sleep_for(std::chrono::milliseconds(70));after=provider.snapshot();
        check(!after.valid&&after.status.find("Missing profiles")!=std::string::npos,"missing live profile fails closed");
        provider.mode(Provider::Demo);frame=await(provider,true);check(frame.valid&&frame.demo,"switch back to demo recovers");
        for(int k=0;k<100;++k){provider.mode(k%2?Provider::Demo:Provider::Live);provider.reload();}
        provider.mode(Provider::Demo);frame=await(provider,true);check(frame.valid&&frame.demo,"rapid source switches converge to the latest request");
    }
    check(std::filesystem::exists(folder),"provider destructor returned after worker shutdown");
    std::filesystem::remove_all(folder);
    std::cout<<"PASS: "<<checks<<" Windows provider checks\n";return 0;
}catch(const std::exception& error){std::cerr<<"FAIL: "<<error.what()<<"\n";return 1;}}
