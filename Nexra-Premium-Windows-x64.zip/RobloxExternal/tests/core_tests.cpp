#include "core.hpp"
#include "settings.hpp"
#include "state.hpp"
#include <random>
#include <thread>
#include <filesystem>
#include <iostream>
#include <fstream>
#include <stdexcept>
using namespace ext;
int checks=0;
void check(bool result,const char* label){++checks;if(!result) throw std::runtime_error(label);}
bool close(float a,float b){return std::abs(a-b)<.001f;}
Entity player(uint64_t id,float x,uint64_t team=2){
    Entity e;e.id=id;e.team=team;e.health=80;e.maxHealth=100;e.name="Test";
    for(int k:{Head,Torso,Root}){auto& p=e.parts[k];p.valid=true;p.position={x,k==Head?2.f:0.f,0};p.size={1,1,1};}
    return e;
}
int main(){try{
    Mat4 identity{};identity.m[0]=identity.m[5]=identity.m[10]=identity.m[15]=1;
    auto center=project(identity,{0,0,0},800,600);check(center&&close(center->x,400)&&close(center->y,300),"projection center");
    auto corner=project(identity,{-1,1,0},800,600);check(corner&&close(corner->x,0)&&close(corner->y,0),"projection top-left");
    Mat4 perspective=identity;perspective.m[15]=0;perspective.m[14]=1;
    check(!project(perspective,{0,0,-1},800,600),"behind-camera rejected");
    check(!project(identity,{std::numeric_limits<float>::quiet_NaN(),0,0},800,600),"NaN rejected");
    check(!project(identity,{0,0,0},0,600),"zero viewport rejected");
    check(onScreen({20,20},800,600)&&!onScreen({-1,20},800,600),"on-screen filtering");
    Part cube;cube.valid=true;cube.size={2,2,2};auto corners=cube.corners();
    check(close(corners[0].x,-1)&&close(corners[7].y,1),"part corners");
    Entity e;e.parts[Root]=cube;auto b=bounds(e,identity,800,600);
    check(b&&close(b->left,0)&&close(b->right,800)&&close(b->bottom,600),"2D bounds");
    e.parts[Root].valid=false;check(!bounds(e,identity,800,600),"missing parts have no bounds");
    e.geometry.push_back(cube);check(bool(bounds(e,identity,800,600)),"R6 physical geometry kept for bounds");
    Snapshot s;s.valid=true;s.localTeam=1;s.view=identity;s.view.m[0]=s.view.m[5]=.01f;
    s.entities={player(1,1,1),player(2,12),player(3,4)};AimOptions o;o.radius=60;o.maxDistance=1000;
    auto t=selectTarget(s,o,{400,300},800,600);check(t&&t->id==3,"nearest non-teammate selected");
    t=selectTarget(s,o,{400,300},800,600,2);check(t&&t->id==2,"sticky target preserved");
    o.sticky=false;t=selectTarget(s,o,{400,300},800,600,2);check(t&&t->id==3,"sticky can be disabled");
    s.entities[2].health=0;t=selectTarget(s,o,{400,300},800,600);check(t&&t->id==2,"dead player excluded");
    o.radius=10;check(!selectTarget(s,o,{400,300},800,600),"outside FOV excluded");
    o.radius=60;o.teamCheck=false;t=selectTarget(s,o,{400,300},800,600);check(t&&t->id==1,"team filter can be disabled");
    o.maxDistance=.5f;check(!selectTarget(s,o,{400,300},800,600),"world-distance limit");
    o.maxDistance=1000;o.teamCheck=true;s.entities={player(5,4)};s.entities[0].parts[Head].valid=false;
    o.bone=0;check(!selectTarget(s,o,{400,300},800,600),"missing chosen bone rejected");
    o.bone=3;check(bool(selectTarget(s,o,{400,300},800,600)),"adaptive selects available bone");
    o.bone=2;o.prediction=true;o.leadMs=100;s.entities[0].velocity={10,0,0};
    t=selectTarget(s,o,{400,300},800,600);check(t&&close(t->world.x,5),"linear velocity prediction");
    o.maxStep=5;o.smoothingMs=0;auto step=aimStep({500,400},{400,300},o,.016f);
    check(close(std::hypot(step.x,step.y),5),"input step length capped");
    o.maxStep=1000;o.smoothingMs=100;auto a=aimStep({450,300},{400,300},o,.005f),z=aimStep({450,300},{400,300},o,.016f);
    check(a.x>0&&z.x>a.x&&z.x<50,"time-based smoothing");
    o.inputMode=1;o.smoothingMs=0;o.gain=4;step=aimStep({410,300},{400,300},o,.016f);check(close(step.x,10),"cursor mode ignores camera gain");
    s.valid=false;check(!selectTarget(s,o,{400,300},800,600),"invalid snapshot rejected");s.valid=true;
    s.entities[0].health=std::numeric_limits<float>::quiet_NaN();
    check(!selectTarget(s,o,{400,300},800,600),"NaN health rejected");
    s.entities={player(10,8),player(11,4)};s.entities[1].parts[Root].position.z=99;
    o.prediction=false;o.bone=2;o.priority=1;
    t=selectTarget(s,o,{400,300},800,600);check(t&&t->id==10,"world-distance priority");
    o.priority=0;t=selectTarget(s,o,{400,300},800,600);check(t&&t->id==11,"screen-distance priority");
    Settings settings;check(!settings.aim.enabled,"aim off by default");
    settings.aim.radius=20000;settings.thickness=-9;settings.enemy[0]=9;settings.frameCap=0;settings.clamp();
    check(close(settings.aim.radius,650)&&close(settings.thickness,1)&&settings.frameCap==30&&close(settings.enemy[0],1),"settings clamped");
    auto file=std::filesystem::temp_directory_path()/("nexra-test-"+std::to_string(Clock::now().time_since_epoch().count())+".ini");
    settings.aim.enabled=true;settings.aim.inputMode=1;settings.boxStyle=3;
    check(settings.save(file),"settings save");Settings loaded;check(loaded.load(file),"settings load");
    check(loaded.aim.enabled&&loaded.aim.inputMode==1&&loaded.boxStyle==3&&close(loaded.aim.radius,650),"settings round-trip");
    {std::ofstream f(file);f<<"[Aim]\nradius=nan\ngain=not-a-number\nbone=99999999999999999999\n[Offsets]\nGood=0x1f8\nBad=0xABCxyz\n";}
    loaded=Settings{};loaded.load(file);check(close(loaded.aim.radius,160)&&close(loaded.aim.gain,1),"invalid numeric settings use defaults");
    Ini ini;check(ini.load(file),"INI loaded");check(ini.offset("Offsets.Good")==0x1f8&&ini.offset("Offsets.Bad")==0,"hex parsing exact");
    auto nan=std::numeric_limits<float>::quiet_NaN(),inf=std::numeric_limits<float>::infinity();
    check(!project(identity,{0,0,0},inf,600)&&!project(identity,{0,0,0},800,nan),"non-finite viewport rejected");
    check(!onScreen({nan,20},800,600),"non-finite screen position rejected");
    check(std::isfinite(length({1e20f,1e20f,1e20f})),"vector length avoids premature square overflow");
    s.valid=true;s.entities={player(20,10)};o=AimOptions{};
    o.radius=nan;check(!selectTarget(s,o,{400,300},800,600),"NaN FOV fails closed");
    o.radius=inf;check(!selectTarget(s,o,{400,300},800,600),"infinite FOV fails closed");
    o.radius=-1;check(!selectTarget(s,o,{400,300},800,600),"negative FOV fails closed");
    o.radius=160;o.maxDistance=nan;check(!selectTarget(s,o,{400,300},800,600),"NaN range fails closed");
    o.maxDistance=1500;o.bone=99;check(!selectTarget(s,o,{400,300},800,600),"unknown target bone fails closed");
    o.bone=0;o.prediction=true;o.leadMs=nan;check(!selectTarget(s,o,{400,300},800,600),"NaN lead time fails closed");
    o=AimOptions{};
    check(aimStep({450,300},{400,300},o,nan).x==0,"NaN delta time emits no movement");
    check(aimStep({450,300},{400,300},o,0).x==0,"zero delta time emits no movement");
    check(aimStep({450,300},{400,300},o,-1).x==0,"negative delta time emits no movement");
    check(aimStep({nan,300},{400,300},o,.016f).x==0,"invalid target emits no movement");
    o.gain=inf;check(aimStep({450,300},{400,300},o,.016f).x==0,"infinite relative gain emits no movement");
    o=AimOptions{};o.smoothingMs=nan;check(aimStep({450,300},{400,300},o,.016f).x==0,"invalid smoothing emits no movement");
    o=AimOptions{};step=aimStep({std::numeric_limits<float>::max(),0},{-std::numeric_limits<float>::max(),0},o,.016f);
    check(finite(step)&&std::hypot(step.x,step.y)<=35.001f,"extreme finite coordinates produce bounded movement");
    Settings bad;bad.aim.radius=nan;bad.aim.gain=inf;bad.thickness=nan;bad.enemy[0]=nan;bad.aim.maxDistance=-inf;bad.clamp();
    check(close(bad.aim.radius,160)&&close(bad.aim.gain,1)&&close(bad.thickness,1.5f)&&close(bad.enemy[0],.9f),"clamp repairs NaN and infinity");
    check(close(bad.aim.maxDistance,1500),"non-finite range restored to default");
    check(healthFraction(50,100)==.5f&&healthFraction(150,100)==1&&healthFraction(-1,100)==0,"health fraction clamped");
    check(healthFraction(nan,100)==0&&healthFraction(50,0)==0&&healthFraction(50,inf)==0,"invalid health safe to render");
    check(validViewMatrix(identity)&&!validViewMatrix(Mat4{}),"matrix structure validation");
    Mat4 corrupt=identity;corrupt.m[0]=nan;check(!validViewMatrix(corrupt),"invalid matrix rejected");
    corrupt={};corrupt.m[3]=corrupt.m[7]=corrupt.m[15]=1;check(!validViewMatrix(corrupt),"constant-output matrix rejected");
    auto behind=edgeDirection(perspective,{0,0,-1});
    check(behind&&behind->x==0&&behind->y==1,"directly-behind actor receives an indicator");
    check(!edgeDirection(identity,{0,0,0}),"centered visible actor has no off-screen direction");
    check(!edgeDirection(identity,{nan,0,0}),"invalid off-screen position rejected");
    auto now=Clock::now();Snapshot gated;gated.valid=true;gated.pid=42;gated.targetWindow=100;gated.sampled=now;
    AimOptions enabled;enabled.enabled=true;
    check(allowMouseOutput(gated,enabled,true,false,true,true,true,now),"valid live input gate");
    auto gate=[&]{return allowMouseOutput(gated,enabled,true,false,true,true,true,now);};
    gated.demo=true;check(!gate(),"demo input blocked even with a simulated foreground target");gated.demo=false;
    gated.valid=false;check(!gate(),"invalid snapshot input blocked");gated.valid=true;
    gated.pid=0;check(!gate(),"missing process input blocked");gated.pid=42;
    gated.targetWindow=0;check(!gate(),"missing game window input blocked");gated.targetWindow=100;
    gated.sampled=now-std::chrono::milliseconds(180);check(!gate(),"data at stale boundary blocked");
    gated.sampled=now+std::chrono::milliseconds(1);check(!gate(),"future timestamp blocked");gated.sampled=now;
    check(!allowMouseOutput(gated,enabled,false,false,true,true,true,now),"source-mode mismatch input blocked");
    check(!allowMouseOutput(gated,enabled,true,true,true,true,true,now),"open menu input blocked");
    check(!allowMouseOutput(gated,enabled,true,false,false,true,true,now),"unfocused input blocked");
    check(!allowMouseOutput(gated,enabled,true,false,true,false,true,now),"released RMB input blocked");
    check(!allowMouseOutput(gated,enabled,true,false,true,true,false,now),"missing target input blocked");
    enabled.enabled=false;check(!gate(),"disabled aim input blocked");enabled.enabled=true;
    RelativeAccumulator accumulator;
    auto output=accumulator.quantize({.7f,.7f},1);
    check(std::hypot(output[0],output[1])<=1,"integer quantization respects diagonal step cap");
    accumulator.reset();output=accumulator.quantize({.3f,0},10);auto output2=accumulator.quantize({.3f,0},10);
    check(output[0]==0&&output2[0]==1,"sub-pixel movement accumulates");
    output=accumulator.quantize({nan,0},10);check(output[0]==0&&accumulator.x==0,"invalid relative input resets remainder");
    accumulator.x=nan;output=accumulator.quantize({.2f,0},10);check(std::isfinite(accumulator.x),"damaged remainder repaired");
    std::mt19937 random(20261001);std::uniform_real_distribution<float> delta(-200,200),cap(1,100);
    bool bounded=true;
    for(int k=0;k<10000;++k){float limit=cap(random);auto movement=accumulator.quantize({delta(random),delta(random)},limit);
        bounded=bounded&&std::hypot(double(movement[0]),double(movement[1]))<=limit+1e-6&&std::isfinite(accumulator.x)&&std::isfinite(accumulator.y);}
    check(bounded,"10000 randomized relative movement cases stay bounded");
    {std::ofstream f(file,std::ios::binary);f<<"\xef\xbb\xbf[aIm]\nenabled=TRUE\nradius=210 ; comment\n[Offsets]\nDecimal=018\nHex=0X1F8\nZero=0\nNegative=-1\nOverflow=18446744073709551616\nQuoted=\"0x80\" # note\n";}
    check(loaded.load(file)&&loaded.aim.enabled&&loaded.aim.radius==210,"BOM case-insensitive keys and boolean words");
    ini.load(file);check(ini.offset("Offsets.Decimal")==18&&ini.offset("Offsets.Hex")==0x1f8,"decimal and hex offsets explicit bases");
    check(ini.parsedOffset("Offsets.Zero").has_value()&&ini.offset("Offsets.Zero")==0,"valid zero offset distinguishable from parse failure");
    check(!ini.parsedOffset("Offsets.Negative")&&!ini.parsedOffset("Offsets.Overflow"),"negative and overflow offsets rejected");
    check(ini.offset("Offsets.Quoted")==0x80,"quoted offset and inline comments");
    {std::ofstream f(file);f<<"[Unrelated]\nFoo=1\n";}
    loaded.aim.radius=321;check(!loaded.load(file)&&loaded.aim.radius==321,"unrelated config rejected without mutation");
    {std::ofstream f(file);f<<"[Aim]\nenabled=false\n";}
    check(loaded.load(file)&&!loaded.aim.enabled&&loaded.aim.radius==160,"partial config uses deterministic defaults");
    {std::ofstream f(file);}
    loaded.aim.radius=222;check(!loaded.load(file)&&loaded.aim.radius==222,"empty config rejected without mutation");
    Settings saved;saved.aim.radius=300;check(saved.save(file),"atomic save replaces an existing file");
    loaded.load(file);check(loaded.aim.radius==300,"replacement settings complete");
    saved.aim.radius=nan;check(saved.save(file)&&loaded.load(file)&&loaded.aim.radius==160,"save sanitizes invalid in-memory values");
    auto folder=file;folder+="-directory";std::filesystem::create_directory(folder);
    {std::ofstream keep(folder/"keep.txt");keep<<"original";}
    check(!saved.save(folder)&&std::filesystem::exists(folder/"keep.txt"),"failed save preserves an existing destination");
    std::filesystem::remove_all(folder);
    SnapshotStore store;auto request=store.consumeRequest();check(request.reload&&request.mode==0,"initial reader request");
    Snapshot liveData;liveData.valid=true;liveData.entities={player(30,10)};
    check(store.publish(liveData,request.revision)&&store.snapshot().valid,"live frame published");
    store.reload();auto after=store.snapshot();check(!after.valid&&after.entities.empty()&&after.revision>request.revision,"reload immediately invalidates old data");
    check(!store.publish(liveData,request.revision)&&!store.snapshot().valid,"in-flight old frame cannot undo a reload");
    request=store.consumeRequest();check(store.publish(liveData,request.revision),"new revision can publish");
    store.setMode(1);after=store.snapshot();check(after.demo&&!after.valid&&after.entities.empty(),"source switch clears live entities immediately");
    request=store.consumeRequest();check(!store.publish(liveData,request.revision),"wrong-mode frame rejected even with current revision");
    Snapshot demoData;demoData.valid=true;demoData.demo=true;check(store.publish(demoData,request.revision),"new demo frame published");
    store.setMode(0);check(!store.publish(demoData,request.revision)&&!store.snapshot().demo,"old demo cannot overwrite live switch");
    auto revision=store.revision();store.setMode(999);check(store.revision()==revision&&store.mode()==0,"unknown source mode ignored");
    std::cout<<"Randomized cases: 10000\n";
    RadarOptions radarOptions;
    auto point=radarPoint({10,0,-10},{0,0,0},100,100,0,false,false,true);
    check(point&&point->offset.x==10&&point->offset.y==-10,"north-up radar axis mapping");
    point=radarPoint({100,0,0},{0,0,0},100,100,1.57079632679f,true,false,true);
    check(point&&std::abs(point->offset.x)<.01f&&point->offset.y< -99.9f,"camera-up radar rotation");
    check(!radarPoint({200,0,0},{},100,100,0,false,false,false),"out-of-range radar filtering");
    point=radarPoint({200,25,200},{},100,100,0,false,false,true);
    check(point&&point->edge&&std::hypot(point->offset.x,point->offset.y)<=100.001f&&point->altitude==25,"radar circular edge clamp and altitude");
    point=radarPoint({200,0,50},{},100,100,0,false,true,true);
    check(point&&point->offset.x==100&&point->offset.y==25,"square radar edge mapping");
    check(!radarPoint({nan,0,0},{},100,100,0,false,false,true),"invalid radar position rejected");
    check(!radarPoint({0,0,0},{},0,100,0,false,false,true),"invalid radar range rejected");
    auto parsed=parsePattern("100,0,100;200,-10,200");check(parsed&&parsed->size()==2,"recoil pattern parsed");
    check(!parsePattern("print('hello')")&&!parsePattern("100,0,100;")&&!parsePattern("nan,0,0"),"patterns are data and reject script/trailing/invalid inputs");
    check(!parsePattern("1,0,100")&&!parsePattern("100,900,0")&&!parsePattern("9999,0,0"),"pattern bounds enforced");
    RecoilOptions recoil;recoil.delayMs=50;recoil.mode=0;recoil.vertical=100;
    auto movement=recoilStep(recoil,{},0,.02f);check(movement.y==0,"recoil start delay");
    movement=recoilStep(recoil,{},40,.02f);check(close(movement.y,1),"recoil delayed interval is integrated exactly");
    recoil.mode=1;recoil.delayMs=0;movement=recoilStep(recoil,*parsed,90,.02f);
    check(close(movement.x,-.1f)&&close(movement.y,3),"recoil crossing a pattern segment boundary");
    check(recoilStep(recoil,*parsed,400,.02f).y==0,"finite pattern ends without looping");
    check(recoilStep(recoil,*parsed,90,nan).y==0,"invalid recoil delta time rejected");
    recoil.enabled=true;gated.sampled=now;gated.valid=true;gated.demo=false;gated.pid=42;gated.targetWindow=100;
    check(allowRecoilOutput(gated,recoil,true,false,true,true,true,now),"live recoil gate");
    check(!allowRecoilOutput(gated,recoil,true,false,true,false,true,now),"recoil needs fire button");
    check(!allowRecoilOutput(gated,recoil,true,false,true,true,false,now),"recoil needs aim button");
    gated.demo=true;check(!allowRecoilOutput(gated,recoil,true,false,true,true,true,now),"demo recoil gate");gated.demo=false;
    check(avatarHost(L"tr.rbxcdn.com")&&avatarHost(L"thumbnails.roblox.com"),"official avatar hosts accepted");
    check(!avatarHost(L"rbxcdn.com.attacker.example")&&!avatarHost(L"127.0.0.1")&&!avatarHost(L"evilrbxcdn.com"),"avatar arbitrary hosts rejected");
    Settings premium;premium.readerHz=999;premium.radarStyle.size=nan;premium.recoil.pattern="malformed";premium.aim.axisX=inf;premium.clamp();
    check(premium.readerHz==60&&premium.radarStyle.size==210&&premium.aim.axisX==1&&bool(parsePattern(premium.recoil.pattern)),"new options sanitize invalid data");
    premium.aim.activation=3;premium.aim.deadzone=4;premium.radarStyle.corner=3;premium.recoil.mode=1;premium.onlineAvatar=false;
    check(premium.save(file)&&loaded.load(file)&&loaded.aim.activation==3&&loaded.aim.deadzone==4&&loaded.radarStyle.corner==3&&loaded.recoil.mode==1&&!loaded.onlineAvatar,"new options round-trip");
    SnapshotStore sharedStore;auto first=sharedStore.sharedSnapshot();auto second=sharedStore.sharedSnapshot();
    check(first.get()==second.get(),"immutable snapshots are shared without entity copies");
    auto sharedRequest=sharedStore.consumeRequest();Snapshot next;next.valid=true;next.localName="Test account";
    sharedStore.publish(next,sharedRequest.revision);auto updated=sharedStore.sharedSnapshot();
    check(updated.get()!=first.get()&&updated->localName=="Test account"&&!first->valid,"old shared frame remains immutable");
    s.valid=true;s.entities={player(40,10),player(41,20)};s.entities[0].health=90;s.entities[1].health=20;o=AimOptions{};o.priority=2;
    auto weak=selectTarget(s,o,{400,300},800,600);check(weak&&weak->id==41,"lowest-health target priority");
    o.minHealth=30;weak=selectTarget(s,o,{400,300},800,600);check(weak&&weak->id==40,"minimum aim health filter");
    o=AimOptions{};o.deadzone=4;check(aimStep({403,300},{400,300},o,.016f).x==0,"aim deadzone");
    o.axisX=0;check(aimStep({450,300},{400,300},o,.016f).x==0,"aim horizontal scale can disable an axis");
    o.axisX=1;o.maxSpeed=100;movement=aimStep({800,300},{400,300},o,.01f);check(movement.x<=1.001f,"aim rate limit is time-scaled");
    std::filesystem::remove(file);
    std::cout<<"PASS: "<<checks<<" checks\n";return 0;
}catch(const std::exception& e){std::cerr<<"FAIL after "<<checks<<" checks: "<<e.what()<<"\n";return 1;}}
