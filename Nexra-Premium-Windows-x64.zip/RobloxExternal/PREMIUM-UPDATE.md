# Premium / performance build 1.1.0

## Implemented

- Refined dark/purple menu, larger rounded controls, improved spacing and an avatar-stage panel.
- Account name at the bottom of the menu, without the old profile/initial badge. Optional bottom-left overlay account footer.
- The reader obtains the local username and public user ID only after exact-build live data validates. Demo is explicitly labeled `Demo account`; missing live identity is `Waiting for account`, not a fabricated username.
- Optional full-body public-avatar thumbnail from Roblox HTTPS services. A procedural bacon-hair avatar is always available when identity, network, image or GPU loading is unavailable.
- Aim activation selection: RMB, LMB, Alt or Mouse 4. Added deadzone, time-scaled speed limit, horizontal/vertical scales, acquisition delay, minimum target health and lowest-health priority.
- Radar: circular or square, north-up or camera-up, four placements, size/opacity/marker size, range rings, clipped edge markers, height indicators, optional player labels, selected-player highlight.
- Recoil compensation: steady adjustable mouse rates or a bounded custom-pattern data editor, start delay and per-command limit. Combined relative aim/recoil uses one mouse command, not competing controllers.
- Tunable 10–60 Hz sampling, 250–2500 ms entity-discovery interval and a background render cap. Last sampling-work time is available in Options.
- Immutable shared scene snapshots avoid deep-copying every entity per render frame. Reader sampling slows in the background; live target selection is skipped while the menu is open. Pattern validation is cached rather than reparsed repeatedly.
- Diagnostics identify which stage failed: VisualEngine, Players, LocalPlayer, camera or view data.

## Recoil is not a spread canceller

This feature moves the mouse at user-calibrated rates. It does not alter weapon properties, random spread, server calculations or recoil code. Hold **RMB + LMB** with a hidden menu, foreground game and fresh live data. Both controls default off. Demo never sends commands.

Custom-pattern mode is advanced and not recommended without calibration. It accepts DATA only, not executable Lua, scripts or arbitrary code:

```text
200,0,75;300,0,100;400,0,60
```

Each row means `duration_ms,x_units_per_second,y_units_per_second`. Maximum 16 segments, each 10–5000 ms, rates bounded to ±600, total duration up to 30 seconds. A pattern ends rather than silently looping; releasing the required buttons resets the burst. Invalid input preserves the previous applied pattern.

Speed, fly, silent aim, injected effects and universal spread cancellation are **not implemented**. No fake working buttons were added. These require an actual, tested game-specific integration beyond the read-only data path. This release remains external.

## Avatar privacy and limits

`Public avatar thumbnail` is enabled by default to fulfill the requested automatic avatar display; switch it off in Options for offline fallback.

- Only the detected public numeric user ID is placed in the request to `thumbnails.roblox.com`.
- Image downloads are limited to HTTPS/443 and Roblox thumbnail/CDN hosts.
- Redirects are not followed automatically, certificate checks are not disabled, metadata/image sizes and decoded dimensions are bounded.
- Requests/PNG decoding run on a background worker, not inside drawing. One request per user/enable transition; there is no per-frame polling.
- No login, password, cookie, account token or screenshot is uploaded.
- The image is a public full-body thumbnail, not a live animated model or a perfect ESP rig. The frame around it is illustrative.
- If Roblox returns Pending, blocked content, network errors or an unavailable image, the bacon-hair fallback remains. To retry, toggle the option off/on.

This adds WinHTTP and COM/WIC system API use. Older claims that this application performs no network requests do not describe this release. There is still no network updater, injector, driver or game-memory write.

## Validation

- 131 portable assertions pass, including new radar geometry, recoil integration/pattern validation, host allowlisting, aim settings, option round-trip and immutable snapshot lifetime cases.
- 10,000 randomized integer movement cases per core run.
- Address/undefined sanitizer run passes without reported findings.
- 59 Windows provider assertions pass under Wine.
- Windows x64 executable compiled from this source with MinGW/CMake.
- Actual menu/recoil/radar pages and fallback avatar inspected under Wine/Xvfb; RMB + LMB held in Demo did not change cursor coordinates `(630,448)`.
- The final executable was relaunched and exited normally on End. A separate Windows avatar-worker probe under Wine fetched/decoded test public user ID 1 as 420×420 RGBA (705,600 bytes); this does not verify live identity detection.

Synthetic microbenchmark: 128-entity snapshot, 20,000 reads, Linux GCC -O2: deep-copy access 2164.95 ms; shared access 0.170588 ms. This demonstrates removal of snapshot-copy work only; it is **not a Roblox FPS benchmark or a promised FPS gain**.

Not verified: live local-identity offsets, thumbnail download on native Windows, camera-up yaw in a real game, actual game response to aim/recoil, native MSVC execution, all DPI/GPU/driver combinations, anti-cheat/account outcomes. No claim of zero bugs.

## Run

Close the previous instance with **End**, extract everything into a new writable folder and run `run-demo.bat` first. `RobloxExternal.exe` is already compiled. Run `run-live.bat` only with the exact supported build. The default layout targets `version-02c37bc51a384b8f`; a later build still fails closed.
