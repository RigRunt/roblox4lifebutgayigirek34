# Nexra External — Premium / performance build 1.1.0

Windows x64 C++17 / Dear ImGui / DirectX 11 overlay with a refined dark/purple menu, automatic local-account labels, optional public avatar, improved tactical radar, more aim controls and calibrated recoil compensation.

**Already compiled:** `RobloxExternal.exe` is supplied. You do not need a compiler to run it. This remains an external, read-only game-data reader, not an injected internal program. Current live compatibility has not been verified on a Windows Roblox session.

## Start

Requires Windows 10/11 x64, DirectX 11, a writable extracted folder and windowed/borderless game rendering.

1. Close any old copy with **End**. A second launch reveals the existing instance, not a new build.
2. Extract the entire ZIP. Keep `assets` and `profiles` beside the EXE.
3. Run `run-demo.bat` first. Simulated entities and the `Demo account` label are explicit; Demo never sends mouse commands.
4. Run `run-live.bat` for exact-build game reads. Join an experience and inspect Diagnostics.
5. **Insert** toggles the menu; **End** exits and saves settings.

Aim and recoil are off with clean default settings. Do not import old settings if you want those defaults; presets can retain an enabled state.

## Pages and features

| Page | Controls |
|---|---|
| Aimbot | Configurable activation (RMB/LMB/Alt/Mouse 4), head/torso/root/adaptive, screen/world/health priority, team/sticky filters, FOV and origin, smoothing, fixed-time lead, deadzone, axis scales, acquisition delay, minimum health, speed/step limits, relative/absolute output |
| Recoil | Steady X/Y rates or bounded custom-pattern DATA, start delay, maximum step, input status; no random-spread cancellation |
| Players | Full/corner/world-AABB 3D boxes, labels, health/numbers/positions, skeleton, tracers, head circle, fill, arrows, colors, filtering |
| Radar | Circle/square, north/camera up, four placements, size/opacity/dots, rings, edge markers, height indicators, names and selected-player highlight |
| Extras | Crosshair, FOV/target line, watermark, distances/teams and filters |
| Profiles | Live/Demo, local settings, three preset slots, quick presets |
| Options | VSync, foreground/background cap, reader Hz, discovery interval, work timing, avatar/footer switches and reload |
| Diagnostics | Connection stage, local username/public ID, process/build, entity count, revision/data age and input state |

The bottom account name comes from validated local-player data. Missing identity is shown as `Waiting for account`, not invented. The optional avatar is a public full-body thumbnail; the bacon-hair fallback is an illustration. Neither preview represents a live animated player rig.

## Network/privacy

The requested public avatar option is on by default. It sends only the detected public user ID to Roblox's HTTPS thumbnail service and downloads the resulting image from Roblox CDN hosts. Turn it off for offline fallback. Downloads and decoding happen in a separate worker with host/protocol/size/dimension limits. No login, cookie, password, token, screenshot or game-state upload is performed.

There is no network updater, telemetry collector, hidden downloader, driver, injector, remote thread or game-memory write. This release DOES make optional avatar image requests; older "no network" claims apply only to older builds.

## Limits

- The included numeric profile targets exactly **`version-02c37bc51a384b8f`**. A later version fails closed. Do not change its version label to bypass that gate.
- The profile source and mapping are in `profiles/SOURCE.json`; its downloaded numeric source is retained. See `PROFILE-UPDATE.md` for the previous mismatch repair.
- Matching versions are not proof of valid layouts. Protected read access, object changes or unsupported rigs can prevent live data.
- Mouse output requires fresh valid live data, correct foreground game window, a hidden menu and required activation buttons. Focus/keys are rechecked before output.
- Recoil compensation moves the mouse; it is NOT a recoil-code patch or spread canceller. Custom patterns are data, not executable scripts.
- Speed/fly, silent aim, visibility raycasts, injected chams and universal spread cancellation are not implemented. There are no pretend working switches for them.
- No game acceptance, anti-cheat compatibility, account-outcome, native-GPU or zero-bug guarantee is made.

See `PREMIUM-UPDATE.md` and `VALIDATION.md` for details and test scope.

## Build locally (optional)

`build.bat` performs an offline build using Windows x64 MinGW-w64 or Visual Studio 2022 Build Tools with C++ and the Windows SDK. Dear ImGui and Inter are bundled with licenses. No package downloads or remote scripts are run. `build.bat --no-pause` is available.

```bat
cmake -S . -B build-cmake -A x64
cmake --build build-cmake --config Release
```

The supplied binary was cross-built with MinGW and has static C++/thread runtimes. DirectX, WinHTTP, COM/WIC and ordinary Windows APIs are system dependencies. The MSVC branch has not been executed on native Windows.

## Tests

Portable tests:

```bash
cmake -S . -B build-tests -DEXTERNAL_CORE_TESTS=ON
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

Windows provider tests:

```bat
cmake -S . -B build-provider-tests -A x64 -DEXTERNAL_PROVIDER_TESTS=ON
cmake --build build-provider-tests --config Release
ctest --test-dir build-provider-tests -C Release --output-on-failure
```

Settings/presets and `external.log` are local to the extracted folder. The EXE is unsigned. The hash manifest checks delivery integrity, not an independent security certification.
