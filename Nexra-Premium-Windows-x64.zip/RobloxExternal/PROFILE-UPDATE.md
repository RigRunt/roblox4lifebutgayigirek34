> Historical profile-only repair record. The current archive is now a newly compiled 1.1.0 build; see PREMIUM-UPDATE.md and VALIDATION.md.

# Exact-build profile update — 2026-10-01

## What the screenshot establishes

The program found `RobloxPlayerBeta.exe` and identified `version-02c37bc51a384b8f`. The previous profile expected `version-4310300497aa4917`, so its exact-build gate blocked entity reads and mouse output. Compilation and demo tests did not establish compatibility with this newer build.

## What this package changes

The executable and application source are unchanged from the compiled bug-fix build 1.0.1. You do not need a compiler. This delivery replaces the data profile with numeric values published for exactly `version-02c37bc51a384b8f` / `0.741.0.7411058`.

**11 numeric fields changed:**

| Field | Previous | New |
|---|---|---|
| VisualEngine.Pointer | `0x846f768` | `0x858d208` |
| FakeDataModel.Pointer | `0x8e42c98` | `0x8b54980` |
| Player.LocalPlayer | `0x130` | `0x120` |
| Player.ModelInstance | `0x298` | `0x288` |
| Player.Team | `0x2d8` | `0x2c8` |
| BasePart.Primitive | `0x188` | `0x178` |
| Primitive.Size | `0x1c4` | `0x1bc` |
| Humanoid.Health | `0x190` | `0x180` |
| Humanoid.MaxHealth | `0x1a8` | `0x198` |
| Workspace.CurrentCamera | `0x4b8` | `0x4a8` |
| Camera.Position | `0xfc` | `0xec` |

The source document was downloaded as JSON only, not executable code, and matched its publisher's SHA-256 `dd5fa2364ca7d90da2201cd230258fff74fcecb0fb5e827df504e8384e28c8b0`. The relevant fields present in the publisher's separate `verified` dump agree with these mapped values; its `Humanoid.Health_XML` matches the composed `Humanoid.Health` value. Publisher verification is not verification of this application on your machine.

The publisher's Instance evidence describes a container pointer with begin/end bounds and 16-byte child entries, a name container at `+0x70` with a string at `+0x8`, and the class-name pointer route. Those routes are consistent with the existing reader's assumptions. Runtime validity still requires testing.

Source: https://www.rbxoffsets.com/api/v1/windows/offsets/version-02c37bc51a384b8f/final/offsets.json

Corroborating dump: https://www.rbxoffsets.com/api/v1/windows/offsets/version-02c37bc51a384b8f/verified/offsets.json

`profiles/SOURCE.json` records the mapping/provenance; `profiles/offsets-source.json` preserves the exact downloaded document. No updater, executor or third-party injector was added.

## Use the full ZIP

1. Close the old Nexra instance with **End**. Opening another copy while it is running reveals the old instance; it does not switch to the new files.
2. Extract this entire new ZIP to a writable folder.
3. Launch `run-live.bat` from that new folder, then join your Roblox experience.
4. Open Diagnostics. The profile now expects `version-02c37bc51a384b8f`.
5. If the installed build is unchanged, the old build-mismatch condition should no longer apply. That is not a promise of successful subsequent memory reads.

## Update an existing folder instead

You can replace the entire `profiles` folder in your existing installation with the one in this ZIP while the application is closed. Preserve your own `settings.ini` and presets. Start your existing EXE again, or click **Retry / reload profile** after the folder has been replaced.

## What has and has not been tested

- Published numeric JSON downloaded and SHA-256 checked.
- Profile values mapped and compared with available verified-source values.
- Portable core/settings/state suite rerun: 101 assertions and 10,000 randomized movement cases passed.
- Existing EXE is the same previously compiled and Wine-smoke-tested bug-fix binary; no rebuild was needed for this data-only change.
- **Not tested:** this profile with the user's Windows process, real entities, local account/profile display, real ESP alignment, protected read access or camera response.

If Diagnostics progresses to `Data validation failed` or read access is denied, send the new Diagnostics screenshot and `external.log`; that indicates a separate stage to investigate. Do not disable the validation or rename the profile to bypass a later build mismatch.

## Architecture

This remains external. It has not been converted to an injected internal application. An internal version would require a real, tested in-process integration and a loading mechanism; producing a DLL alone would not establish either. The identified blocker in the provided screenshot is addressed here without requiring an injector.
